<?php

namespace App\Infrastructure\Persistence\MarketData;

use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\DB;

class EodArtifactRepository
{
    public function replaceBars($tradeDate, $publicationId, $runId, array $validRows, array $invalidRows, $useHistory = false)
    {
        return DB::transaction(function () use ($tradeDate, $publicationId, $runId, $validRows, $invalidRows, $useHistory) {
            if (! $useHistory) {
                $this->assertLiveArtifactMutationAllowed($tradeDate, $publicationId, 'eod_bars');
            }

            if ($useHistory) {
                DB::table('eod_bars_history')
                    ->where('trade_date', $tradeDate)
                    ->where('publication_id', $publicationId)
                    ->delete();
            } else {
                DB::table('eod_bars')
                    ->where('trade_date', $tradeDate)
                    ->delete();
            }

            DB::table('eod_invalid_bars')
                ->where('trade_date', $tradeDate)
                ->where('run_id', $runId)
                ->delete();

            if (! empty($validRows)) {
                DB::table($useHistory ? 'eod_bars_history' : 'eod_bars')->insert($validRows);
            }

            if (! empty($invalidRows)) {
                DB::table('eod_invalid_bars')->insert($invalidRows);
            }
        });
    }


    public function ensureBarsHistoryFromCurrentTradeDate($tradeDate, $publicationId, $runId)
    {
        if ($publicationId === null || $publicationId === '') {
            return;
        }

        if (DB::table('eod_bars_history')
            ->where('trade_date', $tradeDate)
            ->where('publication_id', $publicationId)
            ->exists()) {
            return;
        }

        $now = Carbon::now(config('market_data.platform.timezone'))->toDateTimeString();
        $bars = $this->applyStableArtifactOrder(
            DB::table('eod_bars')->where('trade_date', $tradeDate)
        )->get();

        $insert = [];
        foreach ($bars as $row) {
            $insert[] = [
                'publication_id' => $publicationId,
                'trade_date' => $row->trade_date,
                'ticker_id' => $row->ticker_id,
                'open' => $row->open,
                'high' => $row->high,
                'low' => $row->low,
                'close' => $row->close,
                'volume' => $row->volume,
                'adj_close' => $row->adj_close,
                'source' => $row->source,
                'run_id' => $runId,
                'created_at' => $now,
            ];
        }

        if (! empty($insert)) {
            DB::table('eod_bars_history')->insert($insert);
        }
    }

    public function loadBarsWindow($tradeDate, $lookbackDays, $requestedPublicationId = null)
    {
        $startDate = Carbon::parse($tradeDate)->subDays($lookbackDays + 10)->toDateString();

        $rows = $this->applyStableArtifactOrder(
            DB::table('eod_bars')->whereBetween('trade_date', [$startDate, $tradeDate])
        )
            ->get()
            ->map(function ($row) {
                return (array) $row;
            })
            ->all();

        if ($requestedPublicationId) {
            $rows = array_values(array_filter($rows, function ($row) use ($tradeDate) {
                return (string) $row['trade_date'] !== (string) $tradeDate;
            }));

            $historyRows = $this->applyStableArtifactOrder(
                DB::table('eod_bars_history')
                    ->where('trade_date', $tradeDate)
                    ->where('publication_id', $requestedPublicationId)
            )
                ->get()
                ->map(function ($row) {
                    return (array) $row;
                })
                ->all();

            $rows = array_merge($rows, $historyRows);
        }

        return collect($rows)
            ->groupBy('ticker_id')
            ->map(function ($group) {
                return collect($group)
                    ->sortBy(function ($row) {
                        return sprintf('%s|%010d', (string) $row['trade_date'], (int) $row['ticker_id']);
                    })
                    ->values()
                    ->all();
            })
            ->all();
    }

    public function replaceIndicators($tradeDate, $runId, array $rows, $publicationId = null, $useHistory = false)
    {
        return DB::transaction(function () use ($tradeDate, $rows, $publicationId, $useHistory) {
            if (! $useHistory) {
                $this->assertLiveArtifactMutationAllowed($tradeDate, $publicationId, 'eod_indicators');
            }

            $table = $useHistory ? 'eod_indicators_history' : 'eod_indicators';
            $query = DB::table($table)->where('trade_date', $tradeDate);

            if ($useHistory) {
                $query->where('publication_id', $publicationId);
            }

            $query->delete();

            if (! empty($rows)) {
                DB::table($table)->insert($rows);
            }
        });
    }

    public function loadIndicatorsForTradeDate($tradeDate, $requestedPublicationId = null)
    {
        $table = $requestedPublicationId ? 'eod_indicators_history' : 'eod_indicators';
        $query = DB::table($table)->where('trade_date', $tradeDate);

        if ($requestedPublicationId) {
            $query->where('publication_id', $requestedPublicationId);
        }

        return $this->applyStableArtifactOrder($query)
            ->get()
            ->keyBy('ticker_id')
            ->map(function ($row) {
                return (array) $row;
            })
            ->all();
    }

    public function loadBarsForTradeDate($tradeDate, $requestedPublicationId = null)
    {
        $table = $requestedPublicationId ? 'eod_bars_history' : 'eod_bars';
        $query = DB::table($table)->where('trade_date', $tradeDate);

        if ($requestedPublicationId) {
            $query->where('publication_id', $requestedPublicationId);
        }

        return $this->applyStableArtifactOrder($query)
            ->get()
            ->keyBy('ticker_id')
            ->map(function ($row) {
                return (array) $row;
            })
            ->all();
    }


    public function loadCanonicalBarTickerIdsForTradeDate($tradeDate, $requestedPublicationId = null)
    {
        if ($requestedPublicationId !== null && $requestedPublicationId !== '') {
            return $this->loadCandidateScopedBarTickerIdsForTradeDate($tradeDate, $requestedPublicationId);
        }

        return array_map('intval', array_keys($this->loadBarsForTradeDate($tradeDate, null)));
    }

    private function loadCandidateScopedBarTickerIdsForTradeDate($tradeDate, $publicationId)
    {
        $publicationId = (int) $publicationId;
        $tickerIds = [];

        foreach (['eod_bars_history', 'eod_bars'] as $table) {
            $rows = DB::table($table)
                ->where('trade_date', $tradeDate)
                ->where('publication_id', $publicationId)
                ->pluck('ticker_id')
                ->all();

            foreach ($rows as $tickerId) {
                $tickerIds[(int) $tickerId] = true;
            }
        }

        ksort($tickerIds);

        return array_keys($tickerIds);
    }

    public function replaceEligibility($tradeDate, $runId, array $rows, $publicationId = null, $useHistory = false)
    {
        return DB::transaction(function () use ($tradeDate, $rows, $publicationId, $useHistory) {
            if (! $useHistory) {
                $this->assertLiveArtifactMutationAllowed($tradeDate, $publicationId, 'eod_eligibility');
            }

            $table = $useHistory ? 'eod_eligibility_history' : 'eod_eligibility';
            $query = DB::table($table)->where('trade_date', $tradeDate);

            if ($useHistory) {
                $query->where('publication_id', $publicationId);
            }

            $query->delete();

            if (! empty($rows)) {
                DB::table($table)->insert($rows);
            }
        });
    }

    public function historySnapshotExists($publicationId)
    {
        return DB::table('eod_bars_history')->where('publication_id', $publicationId)->exists()
            && DB::table('eod_indicators_history')->where('publication_id', $publicationId)->exists()
            && DB::table('eod_eligibility_history')->where('publication_id', $publicationId)->exists();
    }

    public function snapshotPublicationFromCurrentTables($tradeDate, $publicationId, $runId)
    {
        $now = Carbon::now(config('market_data.platform.timezone'))->toDateTimeString();

        if (! DB::table('eod_bars_history')->where('publication_id', $publicationId)->exists()) {
            $bars = $this->applyStableArtifactOrder(
                DB::table('eod_bars')
                    ->where('trade_date', $tradeDate)
                    ->where('publication_id', $publicationId)
            )->get();

            $insert = [];
            foreach ($bars as $row) {
                $insert[] = [
                    'publication_id' => $publicationId,
                    'trade_date' => $row->trade_date,
                    'ticker_id' => $row->ticker_id,
                    'open' => $row->open,
                    'high' => $row->high,
                    'low' => $row->low,
                    'close' => $row->close,
                    'volume' => $row->volume,
                    'adj_close' => $row->adj_close,
                    'source' => $row->source,
                    'run_id' => $runId,
                    'created_at' => $now,
                ];
            }

            if (! empty($insert)) {
                DB::table('eod_bars_history')->insert($insert);
            }
        }

        if (! DB::table('eod_indicators_history')->where('publication_id', $publicationId)->exists()) {
            $indicators = $this->applyStableArtifactOrder(
                DB::table('eod_indicators')
                    ->where('trade_date', $tradeDate)
                    ->where('publication_id', $publicationId)
            )->get();

            $insert = [];
            foreach ($indicators as $row) {
                $insert[] = [
                    'publication_id' => $publicationId,
                    'trade_date' => $row->trade_date,
                    'ticker_id' => $row->ticker_id,
                    'is_valid' => $row->is_valid,
                    'invalid_reason_code' => $row->invalid_reason_code,
                    'indicator_set_version' => $row->indicator_set_version,
                    'dv20_idr' => $row->dv20_idr,
                    'atr14_pct' => $row->atr14_pct,
                    'vol_ratio' => $row->vol_ratio,
                    'roc20' => $row->roc20,
                    'hh20' => $row->hh20,
                    'run_id' => $runId,
                    'created_at' => $now,
                ];
            }

            if (! empty($insert)) {
                DB::table('eod_indicators_history')->insert($insert);
            }
        }

        if (! DB::table('eod_eligibility_history')->where('publication_id', $publicationId)->exists()) {
            $eligibility = $this->applyStableArtifactOrder(
                DB::table('eod_eligibility')
                    ->where('trade_date', $tradeDate)
                    ->where('publication_id', $publicationId)
            )->get();

            $insert = [];
            foreach ($eligibility as $row) {
                $insert[] = [
                    'publication_id' => $publicationId,
                    'trade_date' => $row->trade_date,
                    'ticker_id' => $row->ticker_id,
                    'eligible' => $row->eligible,
                    'reason_code' => $row->reason_code,
                    'run_id' => $runId,
                    'created_at' => $now,
                ];
            }

            if (! empty($insert)) {
                DB::table('eod_eligibility_history')->insert($insert);
            }
        }
    }

    public function promotePublicationHistoryToCurrent($tradeDate, $publicationId, $runId)
    {
        $now = Carbon::now(config('market_data.platform.timezone'))->toDateTimeString();

        DB::table('eod_bars')->where('trade_date', $tradeDate)->delete();

        $bars = $this->applyStableArtifactOrder(
            DB::table('eod_bars_history')
                ->where('trade_date', $tradeDate)
                ->where('publication_id', $publicationId)
        )->get();

        $insert = [];
        foreach ($bars as $row) {
            $insert[] = [
                'trade_date' => $row->trade_date,
                'ticker_id' => $row->ticker_id,
                'open' => $row->open,
                'high' => $row->high,
                'low' => $row->low,
                'close' => $row->close,
                'volume' => $row->volume,
                'adj_close' => $row->adj_close,
                'source' => $row->source,
                'run_id' => $runId,
                'publication_id' => $publicationId,
                'created_at' => $now,
            ];
        }

        if (! empty($insert)) {
            DB::table('eod_bars')->insert($insert);
        }

        DB::table('eod_indicators')->where('trade_date', $tradeDate)->delete();

        $indicators = $this->applyStableArtifactOrder(
            DB::table('eod_indicators_history')
                ->where('trade_date', $tradeDate)
                ->where('publication_id', $publicationId)
        )->get();

        $insert = [];
        foreach ($indicators as $row) {
            $insert[] = [
                'trade_date' => $row->trade_date,
                'ticker_id' => $row->ticker_id,
                'is_valid' => $row->is_valid,
                'invalid_reason_code' => $row->invalid_reason_code,
                'indicator_set_version' => $row->indicator_set_version,
                'dv20_idr' => $row->dv20_idr,
                'atr14_pct' => $row->atr14_pct,
                'vol_ratio' => $row->vol_ratio,
                'roc20' => $row->roc20,
                'hh20' => $row->hh20,
                'run_id' => $runId,
                'publication_id' => $publicationId,
                'created_at' => $now,
            ];
        }

        if (! empty($insert)) {
            DB::table('eod_indicators')->insert($insert);
        }

        DB::table('eod_eligibility')->where('trade_date', $tradeDate)->delete();

        $elig = $this->applyStableArtifactOrder(
            DB::table('eod_eligibility_history')
                ->where('trade_date', $tradeDate)
                ->where('publication_id', $publicationId)
        )->get();

        $insert = [];
        foreach ($elig as $row) {
            $insert[] = [
                'trade_date' => $row->trade_date,
                'ticker_id' => $row->ticker_id,
                'eligible' => $row->eligible,
                'reason_code' => $row->reason_code,
                'run_id' => $runId,
                'publication_id' => $publicationId,
                'created_at' => $now,
            ];
        }

        if (! empty($insert)) {
            DB::table('eod_eligibility')->insert($insert);
        }
    }

    protected function assertLiveArtifactMutationAllowed($tradeDate, $publicationId, $artifactTable)
    {
        $query = DB::table($artifactTable.' as artifact')
            ->join('eod_publications as pub', 'pub.publication_id', '=', 'artifact.publication_id')
            ->leftJoin('eod_runs as run', 'run.run_id', '=', 'pub.run_id')
            ->where('artifact.trade_date', $tradeDate)
            ->where('pub.seal_state', 'SEALED')
            ->where(function ($query) {
                $query->where('pub.is_current', 1)
                    ->orWhere(function ($query) {
                        $query->where('run.terminal_status', 'SUCCESS')
                            ->where('run.publishability_state', 'READABLE');
                    });
            });

        if ($publicationId !== null && $publicationId !== '') {
            $query->where('artifact.publication_id', '<>', $publicationId);
        }

        if ($query->exists()) {
            throw new \RuntimeException('SEALED_DATASET_MUTATION_BLOCKED: '.$artifactTable.' for trade date '.$tradeDate.' is already sealed/finalized/readable. Use correction history flow instead of mutating the baseline dataset.');
        }
    }

    protected function applyStableArtifactOrder(Builder $query): Builder
    {
        return $query
            ->orderBy('trade_date')
            ->orderBy('ticker_id');
    }
}

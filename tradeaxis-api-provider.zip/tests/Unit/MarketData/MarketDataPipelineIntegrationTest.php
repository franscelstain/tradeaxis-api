<?php

use App\Application\MarketData\Services\CoverageGateEvaluator;
use App\Application\MarketData\Services\DeterministicHashService;
use App\Application\MarketData\Services\EligibilityDecisionService;
use App\Application\MarketData\Services\EodBarsIngestService;
use App\Application\MarketData\Services\EodEligibilityBuildService;
use App\Application\MarketData\Services\EodIndicatorsComputeService;
use App\Application\MarketData\Services\FinalizeDecisionService;
use App\Application\MarketData\Services\IndicatorVectorService;
use App\Application\MarketData\Services\MarketDataPipelineService;
use App\Application\MarketData\Services\MarketDataBackfillService;
use App\Application\MarketData\Services\MarketDataEvidenceExportService;
use App\Application\MarketData\Services\PublicationDiffService;
use App\Application\MarketData\Services\PublicationFinalizeOutcomeService;
use App\Infrastructure\MarketData\Source\LocalFileEodBarsAdapter;
use App\Infrastructure\MarketData\Source\PublicApiEodBarsAdapter;
use App\Infrastructure\Persistence\MarketData\EodArtifactRepository;
use App\Infrastructure\Persistence\MarketData\EodCorrectionRepository;
use App\Infrastructure\Persistence\MarketData\EodPublicationRepository;
use App\Infrastructure\Persistence\MarketData\EodRunRepository;
use App\Infrastructure\Persistence\MarketData\TickerMasterRepository;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Tests\Support\UsesMarketDataSqlite;

class MarketDataPipelineIntegrationTest extends TestCase
{
    use UsesMarketDataSqlite;

    private string $fixtureDir;

    protected function setUp(): void
    {
        parent::setUp();

        $this->bootMarketDataSqlite();
        Carbon::setTestNow('2026-03-25 10:30:00');

        $this->fixtureDir = storage_path('framework/testing/market_data_pipeline');
        if (! is_dir($this->fixtureDir)) {
            mkdir($this->fixtureDir, 0777, true);
        }

        // Penting:
        // LocalFileEodBarsAdapter memakai base_path(config('market_data.source.local_directory')).
        // Jadi nilai config harus RELATIVE terhadap base_path(), bukan absolute path hasil storage_path().
        config()->set('market_data.source.local_directory', 'storage/framework/testing/market_data_pipeline');
        config()->set('market_data.source.file_template_json', '{date}.json');
        config()->set('market_data.source.file_template_csv', '{date}.csv');
        config()->set('market_data.source.default_source_name', 'LOCAL_FILE');
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();

        $this->deleteDirectory($this->fixtureDir);

        parent::tearDown();
    }

    public function test_run_daily_persists_full_db_backed_pipeline_and_current_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $this->assertFileExists($this->fixtureDir.'/2026-03-20.json');

        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file');

        $this->assertSame('SUCCESS', $run->terminal_status);
        $this->assertSame('READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertSame('2026-03-20', $run->trade_date_effective);
        $this->assertSame('LOCAL_FILE', $run->source_name);
        $this->assertSame(1, (int) $run->publication_id);
        $this->assertNull($run->correction_id);
        $this->assertNull($run->final_reason_code);
        $this->assertEquals(1.0, (float) $run->coverage_ratio);
        $this->assertNotNull($run->bars_batch_hash);
        $this->assertNotNull($run->indicators_batch_hash);
        $this->assertNotNull($run->eligibility_batch_hash);

        $publication = DB::table('eod_publications')->where('run_id', $run->run_id)->first();
        $this->assertNotNull($publication);
        $this->assertSame(1, (int) $publication->is_current);
        $this->assertSame('SEALED', $publication->seal_state);

        $pointer = DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first();
        $this->assertNotNull($pointer);
        $this->assertSame((int) $publication->publication_id, (int) $pointer->publication_id);

        $repo = new EodPublicationRepository();
        $resolvedCurrent = $repo->findCurrentPublicationForTradeDate('2026-03-20');
        $resolvedReadableForRun = $repo->findReadableCurrentPublicationForRun($run->run_id, '2026-03-20');

        $this->assertNotNull($resolvedCurrent);
        $this->assertNotNull($resolvedReadableForRun);
        $this->assertSame((int) $publication->publication_id, (int) $resolvedCurrent->publication_id);
        $this->assertSame((int) $publication->publication_id, (int) $resolvedReadableForRun->publication_id);

        $this->assertSame(1, DB::table('eod_bars')->where('trade_date', '2026-03-20')->count());
        $this->assertSame(1, DB::table('eod_indicators')->where('trade_date', '2026-03-20')->count());
        $this->assertSame(1, DB::table('eod_eligibility')->where('trade_date', '2026-03-20')->where('eligible', 1)->count());

        $this->assertSame(1, DB::table('eod_bars_history')->where('publication_id', $publication->publication_id)->count());
        $this->assertSame(1, DB::table('eod_indicators_history')->where('publication_id', $publication->publication_id)->count());
        $this->assertSame(1, DB::table('eod_eligibility_history')->where('publication_id', $publication->publication_id)->count());

        $this->assertTrue(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'RUN_FINALIZED')
                ->exists()
        );
    }





    public function test_promote_daily_without_force_replace_holds_when_valid_current_exists(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 126,
            'low' => 120,
            'close' => 125,
            'volume' => 2500,
            'adj_close' => 125,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $run = $this->makePipeline()->promoteDaily('2026-03-20', 'manual_file');

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('RUN_LOCK_CONFLICT', $run->final_reason_code);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'RUN_FORCE_REPLACE_EXECUTED')
                ->exists()
        );
    }

    public function test_completed_lock_conflict_finalize_rerun_with_force_replace_is_idempotent(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 126,
            'low' => 120,
            'close' => 125,
            'volume' => 2500,
            'adj_close' => 125,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $pipeline = $this->makePipeline();
        $run = $pipeline->promoteDaily('2026-03-20', 'manual_file');

        $pointerBefore = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();
        $eventCountBefore = DB::table('eod_run_events')->where('run_id', $run->run_id)->count();
        $candidateCountBefore = DB::table('eod_publications')->where('run_id', $run->run_id)->count();

        $rerun = $pipeline->completeFinalize(
            new App\Application\MarketData\DTOs\MarketDataStageInput(
                '2026-03-20',
                'manual_file',
                $run->run_id,
                'FINALIZE',
                null,
                true,
                'late operator force replace must not mutate terminal lock-conflict run'
            )
        );

        $pointerAfter = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();
        $eventCountAfter = DB::table('eod_run_events')->where('run_id', $run->run_id)->count();
        $candidateCountAfter = DB::table('eod_publications')->where('run_id', $run->run_id)->count();

        $this->assertSame((int) $run->run_id, (int) $rerun->run_id);
        $this->assertSame('HELD', $rerun->terminal_status);
        $this->assertSame('NOT_READABLE', $rerun->publishability_state);
        $this->assertSame('RUN_LOCK_CONFLICT', $rerun->final_reason_code);
        $this->assertSame((int) $pointerBefore->publication_id, (int) $pointerAfter->publication_id);
        $this->assertSame((int) $pointerBefore->run_id, (int) $pointerAfter->run_id);
        $this->assertSame((int) $eventCountBefore, (int) $eventCountAfter);
        $this->assertSame((int) $candidateCountBefore, (int) $candidateCountAfter);
        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'RUN_FORCE_REPLACE_EXECUTED')
                ->exists()
        );
    }

    public function test_promote_daily_with_force_replace_switches_current_and_records_audit_event(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 126,
            'low' => 120,
            'close' => 125,
            'volume' => 2500,
            'adj_close' => 125,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $run = $this->makePipeline()->promoteDaily(
            '2026-03-20',
            'manual_file',
            null,
            null,
            null,
            true,
            'operator approved replacement after manual import validation'
        );

        $this->assertSame('SUCCESS', $run->terminal_status);
        $this->assertSame('READABLE', $run->publishability_state);
        $this->assertNull($run->final_reason_code);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame((int) $run->run_id, (int) $pointer->run_id);
        $this->assertNotSame(1, (int) $pointer->publication_id);

        $oldPublication = DB::table('eod_publications')->where('publication_id', 1)->first();
        $this->assertSame(0, (int) $oldPublication->is_current);

        $newPublication = DB::table('eod_publications')->where('publication_id', $pointer->publication_id)->first();
        $this->assertSame(1, (int) $newPublication->is_current);
        $this->assertSame(1, (int) $newPublication->supersedes_publication_id);
        $this->assertSame(1, (int) $newPublication->previous_publication_id);
        $this->assertSame(1, (int) $newPublication->replaced_publication_id);

        $event = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FORCE_REPLACE_EXECUTED')
            ->first();

        $this->assertNotNull($event);
        $this->assertSame('WARN', $event->severity);

        $payload = json_decode($event->event_payload_json, true);
        $this->assertTrue((bool) $payload['force_replace']);
        $this->assertSame(1, (int) $payload['previous_publication_id']);
        $this->assertSame((int) $pointer->publication_id, (int) $payload['new_publication_id']);
        $this->assertSame('operator approved replacement after manual import validation', $payload['force_replace_reason']);
    }

    public function test_complete_finalize_is_idempotent_for_already_completed_success_run(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $pipeline = $this->makePipeline();
        $run = $pipeline->runDaily('2026-03-20', 'manual_file');
        $pointerBefore = DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first();
        $eventCountBefore = DB::table('eod_run_events')->where('run_id', $run->run_id)->count();

        $rerun = $pipeline->completeFinalize(
            new App\Application\MarketData\DTOs\MarketDataStageInput('2026-03-20', 'manual_file', $run->run_id, 'FINALIZE', null)
        );

        $pointerAfter = DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first();
        $eventCountAfter = DB::table('eod_run_events')->where('run_id', $run->run_id)->count();

        $this->assertSame((int) $run->run_id, (int) $rerun->run_id);
        $this->assertSame('SUCCESS', $rerun->terminal_status);
        $this->assertSame('READABLE', $rerun->publishability_state);
        $this->assertSame((int) $pointerBefore->publication_id, (int) $pointerAfter->publication_id);
        $this->assertSame((int) $pointerBefore->run_id, (int) $pointerAfter->run_id);
        $this->assertSame((int) $eventCountBefore, (int) $eventCountAfter);
    }

    public function test_completed_success_finalize_rerun_with_invalid_pointer_fails_safe_without_duplicate_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $pipeline = $this->makePipeline();
        $run = $pipeline->runDaily('2026-03-20', 'manual_file');

        $publicationCountBefore = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->count();

        DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->update([
                'publication_version' => 999,
            ]);

        $rerun = $pipeline->completeFinalize(
            new App\Application\MarketData\DTOs\MarketDataStageInput('2026-03-20', 'manual_file', $run->run_id, 'FINALIZE', null)
        );

        $publicationCountAfter = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->count();

        $this->assertSame((int) $run->run_id, (int) $rerun->run_id);
        $this->assertSame('HELD', $rerun->terminal_status);
        $this->assertSame('NOT_READABLE', $rerun->publishability_state);
        $this->assertSame('RUN_LOCK_CONFLICT', $rerun->final_reason_code);
        $this->assertNull($rerun->trade_date_effective);
        $this->assertSame((int) $publicationCountBefore, (int) $publicationCountAfter);
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());
        $this->assertSame(0, DB::table('eod_publications')->where('trade_date', '2026-03-20')->where('is_current', 1)->count());

        $this->assertTrue(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'RUN_FINALIZE_IDEMPOTENCY_POINTER_INVALID')
                ->where('reason_code', 'RUN_LOCK_CONFLICT')
                ->exists()
        );
    }

    public function test_run_daily_success_path_with_post_switch_resolution_mismatch_holds_and_clears_invalid_current_pointer(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $run = $this->makePipelineWithPublications(new PostSwitchResolutionMismatchPublicationRepository())->runDaily('2026-03-20', 'manual_file');

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('RUN_LOCK_CONFLICT', $run->final_reason_code);
        $this->assertNull($run->trade_date_effective);
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());

        $publication = DB::table('eod_publications')->where('run_id', $run->run_id)->first();
        $this->assertNotNull($publication);
        $this->assertSame(0, (int) $publication->is_current);

        $currentRun = DB::table('eod_runs')->where('run_id', $run->run_id)->first();
        $this->assertSame(0, (int) $currentRun->is_current_publication);

        $repo = new EodPublicationRepository();
        $this->assertNull($repo->findCurrentPublicationForTradeDate('2026-03-20'));
        $this->assertNull($repo->findReadableCurrentPublicationForRun($run->run_id, '2026-03-20'));
    }


    public function test_run_daily_api_source_timeout_degraded_hold_persists_attempt_context_in_run_event(): void
    {
        $this->seedTicker(1, 'BBCA');
        config()->set('market_data.source.api.endpoint_template', 'https://example.test/eod/{date}?symbols={symbols}');
        config()->set('market_data.source.api.response_rows_path', 'rows');
        config()->set('market_data.source.api.provider', 'generic');
        config()->set('market_data.provider.api_retry_max', 2);
        config()->set('market_data.provider.api_backoff_ms', 5);
        config()->set('market_data.provider.api_throttle_qps', 1000);

        $calls = 0;
        $this->makePipelineWithApiFetcher(function () use (&$calls) {
            $calls++;

            return [
                'status' => 500,
                'body' => '{"error":"upstream unavailable"}',
            ];
        })->runDaily('2026-03-20', 'api');

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->orderByDesc('run_id')
            ->first();

        $this->assertNotNull($run);
        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame(3, $calls);
        $this->assertStringContainsString('source_name=API_FREE', (string) $run->notes);
        $this->assertStringContainsString('source_provider=generic', (string) $run->notes);
        $this->assertStringContainsString('source_timeout_seconds=20', (string) $run->notes);
        $this->assertStringContainsString('source_retry_max=2', (string) $run->notes);
        $this->assertStringContainsString('source_attempt_count=3', (string) $run->notes);
        $this->assertStringContainsString('source_final_reason_code=RUN_SOURCE_TIMEOUT', (string) $run->notes);
        $this->assertStringContainsString('degraded_mode=NO_BASELINE_HELD', (string) $run->notes);
        $this->assertStringContainsString('final_outcome_note=SOURCE_UNAVAILABLE_NO_BASELINE', (string) $run->notes);

        $stageFailedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'STAGE_FAILED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($stageFailedEvent);
        $this->assertSame('RUN_SOURCE_TIMEOUT', $stageFailedEvent->reason_code);

        $payload = json_decode($stageFailedEvent->event_payload_json, true);
        $this->assertIsArray($payload);
        $this->assertSame('App\Infrastructure\MarketData\Source\SourceAcquisitionException', $payload['exception_class']);
        $this->assertSame('RUN_SOURCE_TIMEOUT', $payload['exception_context']['final_reason_code']);
        $this->assertSame('generic', $payload['exception_context']['provider']);
        $this->assertSame(2, $payload['exception_context']['retry_max']);
        $this->assertSame(3, $payload['exception_context']['attempt_count']);
        $this->assertCount(3, $payload['exception_context']['attempts']);
        $this->assertTrue($payload['exception_context']['attempts'][0]['will_retry']);
        $this->assertFalse($payload['exception_context']['attempts'][2]['will_retry']);
        $this->assertGreaterThan(0, $payload['exception_context']['attempts'][0]['backoff_delay_ms']);
        $this->assertSame(0, $payload['exception_context']['attempts'][2]['backoff_delay_ms']);
    }
    public function test_run_daily_manual_file_with_explicit_input_file_exports_source_context_in_run_evidence(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $explicitFile = $this->fixtureDir.'/manual-explicit-2026-03-20.csv';
        file_put_contents($explicitFile, implode("\n", [
            'ticker_code,trade_date,open,high,low,close,volume,adj_close,captured_at',
            'BBCA,2026-03-20,121,125,120,124,2000,124,2026-03-20T17:20:00+07:00',
        ]));

        config()->set('market_data.source.local_input_file', 'storage/framework/testing/market_data_pipeline/manual-explicit-2026-03-20.csv');

        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file');

        $exportDir = storage_path('framework/testing/market_data_pipeline/evidence-manual-file');
        $result = $this->makeEvidenceExporter()->exportRunEvidence($run->run_id, $exportDir);
        $summary = json_decode(file_get_contents($exportDir.'/run_summary.json'), true);
        $evidencePack = json_decode(file_get_contents($exportDir.'/evidence_pack.json'), true);

        $this->assertSame('LOCAL_FILE', $result['summary']['source_name']);
        $this->assertSame('manual-explicit-2026-03-20.csv', $result['summary']['source_input_file']);
        $this->assertNull($result['summary']['source_summary']);
        $this->assertSame('LOCAL_FILE', $summary['source_context']['source_name']);
        $this->assertSame('manual-explicit-2026-03-20.csv', $summary['source_context']['source_input_file']);
        $this->assertSame('manual-explicit-2026-03-20.csv', $evidencePack['run_summary']['source_context']['source_input_file']);

        $runRow = DB::table('eod_runs')->where('run_id', $run->run_id)->first();
        $this->assertNotNull($runRow);
        $this->assertStringContainsString('source_input_file=manual-explicit-2026-03-20.csv', (string) $runRow->notes);
    }

    public function test_run_daily_api_success_after_retry_exports_source_context_in_run_evidence(): void
    {
        $this->seedTicker(1, 'BBCA');
        config()->set('market_data.source.api.endpoint_template', 'https://example.test/eod/{date}?symbols={symbols}');
        config()->set('market_data.source.api.response_rows_path', 'rows');
        config()->set('market_data.source.api.provider', 'generic');
        config()->set('market_data.source.api.source_name', 'API_FREE');
        config()->set('market_data.provider.api_retry_max', 2);
        config()->set('market_data.provider.api_backoff_ms', 5);
        config()->set('market_data.provider.api_throttle_qps', 1000);

        $calls = 0;
        $run = $this->makePipelineWithApiFetcher(function () use (&$calls) {
            $calls++;

            if ($calls === 1) {
                return [
                    'status' => 429,
                    'body' => '{"error":"rate limit"}',
                ];
            }

            return [
                'status' => 200,
                'body' => json_encode(['rows' => [[
                    'ticker_code' => 'BBCA',
                    'trade_date' => '2026-03-20',
                    'open' => 121,
                    'high' => 125,
                    'low' => 120,
                    'close' => 124,
                    'volume' => 2000,
                    'adj_close' => 124,
                    'captured_at' => '2026-03-20T17:20:00+07:00',
                ]]]),
            ];
        })->runDaily('2026-03-20', 'api');

        $this->assertSame(2, $calls);

        $exportDir = storage_path('framework/testing/market_data_pipeline/evidence-api-retry');
        $result = $this->makeEvidenceExporter()->exportRunEvidence($run->run_id, $exportDir);
        $summary = json_decode(file_get_contents($exportDir.'/run_summary.json'), true);
        $evidencePack = json_decode(file_get_contents($exportDir.'/evidence_pack.json'), true);

        $this->assertSame('API_FREE', $result['summary']['source_name']);
        $this->assertSame('provider=generic | timeout_seconds=20 | retry_max=2 | attempt_count=2 | success_after_retry=yes | final_http_status=200', $result['summary']['source_summary']);
        $this->assertSame('API_FREE', $summary['source_context']['source_name']);
        $this->assertSame(2, $summary['source_context']['attempt_count']);
        $this->assertSame('yes', $summary['source_context']['success_after_retry']);
        $this->assertSame(200, $summary['source_context']['final_http_status']);
        $this->assertSame('API_FREE', $evidencePack['run_summary']['source_context']['source_name']);
        $this->assertSame(2, $evidencePack['run_summary']['source_context']['attempt_count']);

        $runRow = DB::table('eod_runs')->where('run_id', $run->run_id)->first();
        $this->assertNotNull($runRow);
        $this->assertStringContainsString('source_provider=generic', (string) $runRow->notes);
        $this->assertStringContainsString('source_timeout_seconds=20', (string) $runRow->notes);
        $this->assertStringContainsString('source_retry_max=2', (string) $runRow->notes);
        $this->assertStringContainsString('source_attempt_count=2', (string) $runRow->notes);
        $this->assertStringContainsString('source_success_after_retry=yes', (string) $runRow->notes);
        $this->assertStringContainsString('source_final_http_status=200', (string) $runRow->notes);
    }


    public function test_backfill_api_success_after_retry_writes_source_context_per_date_in_summary_artifact(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedMarketCalendarRange('2026-03-20', '2026-03-23');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        config()->set('market_data.source.api.endpoint_template', 'https://example.test/eod/{date}?symbols={symbols}');
        config()->set('market_data.source.api.response_rows_path', 'rows');
        config()->set('market_data.source.api.provider', 'generic');
        config()->set('market_data.source.api.source_name', 'API_FREE');
        config()->set('market_data.provider.api_retry_max', 2);
        config()->set('market_data.provider.api_backoff_ms', 5);
        config()->set('market_data.provider.api_throttle_qps', 1000);

        $attemptsByDate = [];
        $service = $this->makeBackfillServiceWithApiFetcher(function (string $url) use (&$attemptsByDate) {
            $path = (string) parse_url($url, PHP_URL_PATH);
            $date = trim((string) basename($path));

            if ($date === '') {
                parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
                $date = (string) ($query['date'] ?? '');
            }

            $attemptsByDate[$date] = ($attemptsByDate[$date] ?? 0) + 1;

            if ($attemptsByDate[$date] === 1) {
                return [
                    'status' => 429,
                    'body' => '{"error":"rate limit"}',
                ];
            }

            return [
                'status' => 200,
                'body' => json_encode(['rows' => [[
                    'ticker_code' => 'BBCA',
                    'trade_date' => $date,
                    'open' => 121,
                    'high' => 125,
                    'low' => 120,
                    'close' => 124,
                    'volume' => 2000,
                    'adj_close' => 124,
                    'captured_at' => $date.'T17:20:00+07:00',
                ]]]),
            ];
        });

        $outputDir = storage_path('framework/testing/market_data_pipeline/backfill-api-retry');
        $summary = $service->execute('2026-03-20', '2026-03-23', 'api', $outputDir, false);
        $summaryFile = json_decode(file_get_contents($outputDir.'/market_data_backfill_summary.json'), true);

        $this->assertTrue($summary['all_passed']);
        $this->assertCount(2, $summary['cases']);
        $this->assertSame('API_FREE', $summary['cases'][0]['source_name']);
        $this->assertSame('provider=generic | timeout_seconds=20 | retry_max=2 | attempt_count=2 | success_after_retry=yes | final_http_status=200', $summary['cases'][0]['source_summary']);
        $this->assertSame('API_FREE', $summaryFile['cases'][1]['source_name']);
        $this->assertSame('provider=generic | timeout_seconds=20 | retry_max=2 | attempt_count=2 | success_after_retry=yes | final_http_status=200', $summaryFile['cases'][1]['source_summary']);
        $this->assertSame(['2026-03-20' => 2, '2026-03-23' => 2], $attemptsByDate);
    }

    public function test_backfill_manual_file_writes_real_run_source_name_in_summary_artifact(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedMarketCalendarRange('2026-03-20', '2026-03-20');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $outputDir = storage_path('framework/testing/market_data_pipeline/backfill-manual-file');
        $summary = $this->makeBackfillService()->execute('2026-03-20', '2026-03-20', 'manual_file', $outputDir, false);
        $summaryFile = json_decode(file_get_contents($outputDir.'/market_data_backfill_summary.json'), true);

        $this->assertTrue($summary['all_passed']);
        $this->assertSame('LOCAL_FILE', $summary['cases'][0]['source_name']);
        $this->assertArrayNotHasKey('source_summary', $summary['cases'][0]);
        $this->assertSame('LOCAL_FILE', $summaryFile['cases'][0]['source_name']);
        $this->assertArrayNotHasKey('source_input_file', $summaryFile['cases'][0]);
    }


    public function test_run_daily_correction_replaces_current_publication_and_marks_correction_published(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 130,
            'high' => 135,
            'low' => 129,
            'close' => 134,
            'volume' => 2500,
            'adj_close' => 134,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $this->assertFileExists($this->fixtureDir.'/2026-03-20.json');

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('SUCCESS', $run->terminal_status);
        $this->assertSame('READABLE', $run->publishability_state);

        $this->assertSame(
            1,
            DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->where('is_current', 1)
                ->count()
        );

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertGreaterThan(1, (int) $currentPublication->publication_version);
        $this->assertSame(1, (int) $currentPublication->supersedes_publication_id);

        $currentBar = DB::table('eod_bars')
            ->where('trade_date', '2026-03-20')
            ->where('ticker_id', 1)
            ->first();

        $this->assertNotNull($currentBar);
        $this->assertEquals('134', (string) $currentBar->close);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('PUBLISHED', $persistedCorrection->status);
        $this->assertSame(
            'Historical correction published safely via new sealed current publication.',
            $persistedCorrection->final_outcome_note
        );
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNotNull($persistedCorrection->published_at);

        $this->assertSame(1, DB::table('eod_bars_history')->where('publication_id', 1)->count());
        $this->assertSame(
            1,
            DB::table('eod_bars_history')
                ->where('publication_id', $currentPublication->publication_id)
                ->count()
        );

        $this->assertTrue(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }

    public function test_run_daily_correction_with_unchanged_artifacts_cancels_request_and_preserves_current_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);

        $baselineRows = [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]];

        $this->writeBarsFixture('2026-03-20', $baselineRows);
        $baselineRun = $this->makePipeline()->runDaily('2026-03-20', 'manual_file');

        $baselinePublication = DB::table('eod_publications')
            ->where('run_id', $baselineRun->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($baselinePublication);
        $this->assertSame(1, (int) $baselinePublication->is_current);
        $this->assertNotNull($baselinePublication->bars_batch_hash);
        $this->assertNotNull($baselinePublication->indicators_batch_hash);
        $this->assertNotNull($baselinePublication->eligibility_batch_hash);

        $baselineBarsHash = (string) $baselinePublication->bars_batch_hash;
        $baselineIndicatorsHash = (string) $baselinePublication->indicators_batch_hash;
        $baselineEligibilityHash = (string) $baselinePublication->eligibility_batch_hash;

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-same-content', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $this->writeBarsFixture('2026-03-20', $baselineRows);
        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('SUCCESS', $run->terminal_status);
        $this->assertSame('READABLE', $run->publishability_state);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertNotNull($currentPublication->bars_batch_hash);
        $this->assertNotNull($currentPublication->indicators_batch_hash);
        $this->assertNotNull($currentPublication->eligibility_batch_hash);

        $this->assertSame(
            $baselineBarsHash,
            (string) $currentPublication->bars_batch_hash,
            'bars_batch_hash must remain identical for unchanged correction rerun'
        );

        $this->assertSame(
            $baselineIndicatorsHash,
            (string) $currentPublication->indicators_batch_hash,
            'indicators_batch_hash must remain identical for unchanged correction rerun'
        );

        $this->assertSame(
            $baselineEligibilityHash,
            (string) $currentPublication->eligibility_batch_hash,
            'eligibility_batch_hash must remain identical for unchanged correction rerun'
        );

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('CONSUMED_CURRENT', $persistedCorrection->status);
        $this->assertSame(
            'Correction rerun produced unchanged content; current publication preserved without version switch.',
            $persistedCorrection->final_outcome_note
        );
        $this->assertSame((int) $baselineRun->run_id, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);

        $this->assertSame((int) $baselinePublication->publication_id, (int) $currentPublication->publication_id);
        $this->assertSame((int) $baselinePublication->publication_version, (int) $currentPublication->publication_version);

        $this->assertSame(
            1,
            DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertTrue(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_CANCELLED')
                ->exists()
        );
    }



    public function test_run_daily_correction_without_approval_rejects_before_run_creation_and_preserves_current_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'request-without-approval', 'system');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $request->correction_id);
            $this->fail('Expected correction without approval to be rejected before run creation.');
        } catch (\RuntimeException $e) {
            $this->assertSame('Correction request must be APPROVED before execution.', $e->getMessage());
        }

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $request->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('REQUESTED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);
        $this->assertSame(90, (int) $currentPublication->run_id);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(1, DB::table('eod_publications')->where('trade_date', '2026-03-20')->count());
        $this->assertSame(0, DB::table('eod_runs')->where('notes', 'like', 'correction_id='.$request->correction_id.'%')->count());
        $this->assertSame(0, DB::table('eod_run_events')->count());
    }
    public function test_run_daily_correction_with_reseal_failure_keeps_prior_current_and_leaves_candidate_non_current(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 133,
            'high' => 138,
            'low' => 132,
            'close' => 137,
            'volume' => 2800,
            'adj_close' => 137,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-reseal-failure', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipelineWithPublications(
                new ThrowingSealPublicationRepository('Seal persistence failed while recording correction candidate publication.')
            )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected reseal failure to abort correction pipeline.');
        } catch (RuntimeException $e) {
            $this->assertSame('Seal persistence failed while recording correction candidate publication.', $e->getMessage());
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->orderByDesc('run_id')
            ->first();

        $this->assertNotNull($run);
        $this->assertSame('FAILED', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('FAILED', $run->lifecycle_state);
        $this->assertNull($run->sealed_at);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('EXECUTING', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);
        $this->assertSame('SEALED', $currentPublication->seal_state);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('UNSEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);
        $this->assertNull($candidatePublication->sealed_at);

        $stageFailedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'STAGE_FAILED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($stageFailedEvent);
        $this->assertSame('ERROR', $stageFailedEvent->severity);
        $this->assertSame('RUN_SEAL_WRITE_FAILED', $stageFailedEvent->reason_code);
        $this->assertStringContainsString('Seal persistence failed while recording correction candidate publication.', (string) $stageFailedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'RUN_FINALIZED')
                ->exists()
        );

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }


    public function test_run_daily_correction_with_changed_artifacts_and_promotion_failure_holds_and_preserves_prior_current_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-promote-conflict', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new ThrowingPromotionPublicationRepository('Promotion lost run ownership while switching current publication.')
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertSame('2026-03-19', $run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertStringContainsString('Promotion lost run ownership while switching current publication.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }


    public function test_run_daily_correction_with_changed_artifacts_and_malformed_fallback_pointer_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->update([
                'run_id' => 81,
                'updated_at' => '2026-03-19 17:25:00',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-promote-conflict-and-malformed-fallback', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new ThrowingPromotionPublicationRepository('Promotion lost run ownership while switching current publication.')
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $this->assertSame(
            1,
            DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->where('is_current', 1)
                ->count()
        );

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $currentPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($currentPointer);
        $this->assertSame(1, (int) $currentPointer->publication_id);
        $this->assertSame(90, (int) $currentPointer->run_id);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(81, (int) $fallbackPointer->run_id);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertStringContainsString('Promotion lost run ownership while switching current publication.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_changed_artifacts_and_baseline_pointer_mismatch_holds_and_preserves_prior_current_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 132,
            'high' => 137,
            'low' => 131,
            'close' => 136,
            'volume' => 2700,
            'adj_close' => 136,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-baseline-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new BaselineMismatchPromotionPublicationRepository(2, 91, 9)
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertSame('2026-03-19', $run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $this->assertFalse(
            DB::table('eod_publications')
                ->where('publication_id', 2)
                ->exists()
        );

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertStringContainsString('Correction baseline no longer matches current publication pointer.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }

    public function test_run_daily_correction_with_changed_artifacts_and_post_switch_resolution_mismatch_restores_prior_current_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertSame('2026-03-19', $run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $priorRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($priorRun);
        $this->assertSame(1, (int) $priorRun->is_current_publication);

        $candidateRun = DB::table('eod_runs')->where('run_id', $run->run_id)->first();
        $this->assertNotNull($candidateRun);
        $this->assertSame(0, (int) $candidateRun->is_current_publication);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }


    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_malformed_fallback_pointer_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->update([
                'run_id' => 999,
                'updated_at' => '2026-03-19 17:21:00',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-malformed-fallback', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $malformedFallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($malformedFallbackPointer);
        $this->assertSame(999, (int) $malformedFallbackPointer->run_id);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }


    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_missing_pointer_row_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->delete();
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-missing-pointer-row', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $this->assertFalse(
            DB::table('eod_current_publication_pointer')
                ->where('trade_date', '2026-03-19')
                ->exists()
        );

        $fallbackPublication = DB::table('eod_publications')->where('publication_id', 11)->first();
        $this->assertNotNull($fallbackPublication);
        $this->assertSame('SEALED', $fallbackPublication->seal_state);
        $this->assertSame(1, (int) $fallbackPublication->is_current);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_missing_publication_row_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_publications')
            ->where('publication_id', 11)
            ->delete();
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-missing-publication-row', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $this->assertNull(
            DB::table('eod_publications')
                ->where('publication_id', 11)
                ->first()
        );

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_publication_version_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->update([
                'publication_version' => 99,
                'updated_at' => '2026-03-19 17:22:00',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-publication-version-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $malformedFallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($malformedFallbackPointer);
        $this->assertSame(99, (int) $malformedFallbackPointer->publication_version);
        $this->assertSame(11, (int) $malformedFallbackPointer->publication_id);
        $this->assertSame(80, (int) $malformedFallbackPointer->run_id);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }


    public function test_run_daily_correction_with_history_promotion_failure_keeps_prior_current_and_candidate_sealed_non_current(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-history-promotion-failure', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $this->makePipelineWithArtifacts(
            new ThrowingHistoryPromotionArtifactRepository('History promotion to current tables failed during correction finalize.')
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->orderByDesc('run_id')
            ->first();

        $this->assertNotNull($run);
        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNotNull($run->sealed_at);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);
        $this->assertSame('SEALED', $currentPublication->seal_state);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);
        $this->assertNotNull($candidatePublication->sealed_at);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertStringContainsString(
            'History promotion to current tables failed during correction finalize.',
            (string) $finalizedEvent->message
        );

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }

    public function test_run_daily_approved_correction_without_current_baseline_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-without-current-baseline', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected missing current baseline to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $this->assertSame(
            0,
            DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertNull(
            DB::table('eod_current_publication_pointer')
                ->where('trade_date', '2026-03-20')
                ->first()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }





    public function test_run_daily_approved_correction_with_pointer_to_different_trade_date_publication_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToDifferentTradeDatePublication('2026-03-20', '2026-03-19', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-different-trade-date-publication', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected pointer to different-trade-date publication to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('2026-03-19', $publication->trade_date);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }

    public function test_run_daily_approved_correction_with_pointer_to_publication_whose_run_requested_trade_date_mismatches_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToPublicationWithRunRequestedTradeDateMismatch('2026-03-20', '2026-03-19', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-baseline-run-requested-trade-date-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected baseline run requested-trade-date mismatch to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('2026-03-19', (string) $baselineRun->trade_date_requested);
        $this->assertSame('SUCCESS', $baselineRun->terminal_status);
        $this->assertSame('READABLE', $baselineRun->publishability_state);
        $this->assertSame(1, (int) $baselineRun->is_current_publication);

        $baselinePointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($baselinePointer);
        $this->assertSame(1, (int) $baselinePointer->publication_id);
        $this->assertSame(90, (int) $baselinePointer->run_id);
        $this->assertSame(1, (int) $baselinePointer->publication_version);

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }
    public function test_run_daily_approved_correction_with_pointer_to_publication_whose_run_row_is_missing_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToPublicationWithMissingRunForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-publication-whose-run-row-is-missing', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected missing run row behind current pointer publication to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->orderBy('run_id')
            ->get();

        $this->assertCount(0, $run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);
        $this->assertSame(90, (int) $publication->run_id);

        $this->assertNull(DB::table('eod_runs')->where('run_id', 90)->first());

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }


    public function test_run_daily_approved_correction_with_pointer_to_non_readable_run_publication_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToNonReadableRunPublicationForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-non-readable-run-publication', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected non-readable baseline run to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('HELD', $baselineRun->terminal_status);
        $this->assertSame('NOT_READABLE', $baselineRun->publishability_state);
        $this->assertSame(0, (int) $baselineRun->is_current_publication);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }


    public function test_run_daily_approved_correction_with_pointer_to_success_readable_run_marked_non_current_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToReadableRunMarkedNonCurrentForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-readable-run-marked-non-current', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected baseline run current-mirror mismatch to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('SUCCESS', $baselineRun->terminal_status);
        $this->assertSame('READABLE', $baselineRun->publishability_state);
        $this->assertSame(0, (int) $baselineRun->is_current_publication);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }



    public function test_run_daily_approved_correction_with_pointer_to_sealed_publication_marked_non_current_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToSealedPublicationMarkedNonCurrentForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-sealed-publication-marked-non-current', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected publication current-mirror mismatch to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $unexpectedRun = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($unexpectedRun);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(0, (int) $publication->is_current);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('SUCCESS', $baselineRun->terminal_status);
        $this->assertSame('READABLE', $baselineRun->publishability_state);
        $this->assertSame(1, (int) $baselineRun->is_current_publication);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }


    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_trade_date_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_publications')
            ->where('publication_id', 11)
            ->update([
                'trade_date' => '2026-03-18',
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-trade-date-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $corruptedFallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($corruptedFallbackPublication);
        $this->assertSame('2026-03-18', (string) $corruptedFallbackPublication->trade_date);
        $this->assertSame(1, (int) $corruptedFallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_publication_missing_run_row_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_runs')->where('run_id', 80)->delete();
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-missing-run-row', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $corruptedFallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($corruptedFallbackPublication);
        $this->assertSame('2026-03-19', (string) $corruptedFallbackPublication->trade_date);
        $this->assertSame(80, (int) $corruptedFallbackPublication->run_id);
        $this->assertSame(1, (int) $corruptedFallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);
        $this->assertNull(DB::table('eod_runs')->where('run_id', 80)->first());

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_run_id_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->update([
                'run_id' => 999,
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-run-id-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $fallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($fallbackPublication);
        $this->assertSame('2026-03-19', (string) $fallbackPublication->trade_date);
        $this->assertSame(80, (int) $fallbackPublication->run_id);
        $this->assertSame(1, (int) $fallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(999, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $this->assertNull(DB::table('eod_runs')->where('run_id', 999)->first());

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_run_current_mirror_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_runs')
            ->where('run_id', 80)
            ->update([
                'is_current_publication' => 0,
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-run-current-mirror-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $corruptedFallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($corruptedFallbackPublication);
        $this->assertSame('2026-03-19', (string) $corruptedFallbackPublication->trade_date);
        $this->assertSame(80, (int) $corruptedFallbackPublication->run_id);
        $this->assertSame(1, (int) $corruptedFallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(0, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_run_terminal_status_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_runs')
            ->where('run_id', 80)
            ->update([
                'terminal_status' => 'HELD',
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-run-terminal-status-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $fallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($fallbackPublication);
        $this->assertSame('2026-03-19', (string) $fallbackPublication->trade_date);
        $this->assertSame(80, (int) $fallbackPublication->run_id);
        $this->assertSame(1, (int) $fallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('HELD', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_run_publishability_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_runs')
            ->where('run_id', 80)
            ->update([
                'publishability_state' => 'NOT_READABLE',
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-run-publishability-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $fallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($fallbackPublication);
        $this->assertSame('2026-03-19', (string) $fallbackPublication->trade_date);
        $this->assertSame(80, (int) $fallbackPublication->run_id);
        $this->assertSame(1, (int) $fallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('NOT_READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_run_requested_trade_date_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_runs')
            ->where('run_id', 80)
            ->update([
                'trade_date_requested' => '2026-03-18',
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-run-requested-trade-date-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('2026-03-18', (string) $fallbackRun->trade_date_requested);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }
    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_publication_missing_sealed_at_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_publications')
            ->where('publication_id', 11)
            ->update([
                'sealed_at' => null,
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-publication-missing-sealed-at', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $corruptedFallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($corruptedFallbackPublication);
        $this->assertSame('2026-03-19', (string) $corruptedFallbackPublication->trade_date);
        $this->assertSame(80, (int) $corruptedFallbackPublication->run_id);
        $this->assertSame('SEALED', $corruptedFallbackPublication->seal_state);
        $this->assertSame(1, (int) $corruptedFallbackPublication->is_current);
        $this->assertNull($corruptedFallbackPublication->sealed_at);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }

    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_unsealed_publication_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_publications')
            ->where('publication_id', 11)
            ->update([
                'seal_state' => 'UNSEALED',
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-unsealed-publication', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $corruptedFallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($corruptedFallbackPublication);
        $this->assertSame('2026-03-19', (string) $corruptedFallbackPublication->trade_date);
        $this->assertSame(80, (int) $corruptedFallbackPublication->run_id);
        $this->assertSame('UNSEALED', $corruptedFallbackPublication->seal_state);
        $this->assertSame(1, (int) $corruptedFallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_correction_with_post_switch_resolution_mismatch_and_fallback_publication_current_mirror_mismatch_does_not_invent_effective_trade_date(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);
        DB::table('eod_publications')
            ->where('publication_id', 11)
            ->update([
                'is_current' => 0,
                'updated_at' => '2026-03-19 17:22:30',
            ]);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 136,
            'low' => 130,
            'close' => 135,
            'volume' => 2600,
            'adj_close' => 135,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-post-switch-resolution-mismatch-and-fallback-publication-current-mirror-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $run = $this->makePipelineWithPublications(
            new PostSwitchResolutionMismatchPublicationRepository()
        )->runDaily('2026-03-20', 'manual_file', $approved->correction_id);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('COMPLETED', $run->lifecycle_state);
        $this->assertNull($run->trade_date_effective);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('RESEALED', $persistedCorrection->status);
        $this->assertSame(90, (int) $persistedCorrection->prior_run_id);
        $this->assertSame((int) $run->run_id, (int) $persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $currentPublication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('is_current', 1)
            ->first();

        $this->assertNotNull($currentPublication);
        $this->assertSame(1, (int) $currentPublication->publication_id);
        $this->assertSame(1, (int) $currentPublication->publication_version);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(1, (int) $pointer->publication_version);

        $candidatePublication = DB::table('eod_publications')
            ->where('run_id', $run->run_id)
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($candidatePublication);
        $this->assertSame('SEALED', $candidatePublication->seal_state);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertSame(1, (int) $candidatePublication->supersedes_publication_id);

        $corruptedFallbackPublication = DB::table('eod_publications')
            ->where('publication_id', 11)
            ->first();

        $this->assertNotNull($corruptedFallbackPublication);
        $this->assertSame('2026-03-19', (string) $corruptedFallbackPublication->trade_date);
        $this->assertSame(80, (int) $corruptedFallbackPublication->run_id);
        $this->assertSame(0, (int) $corruptedFallbackPublication->is_current);

        $fallbackPointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-19')
            ->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertSame(80, (int) $fallbackPointer->run_id);
        $this->assertSame(1, (int) $fallbackPointer->publication_version);

        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);

        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->orderByDesc('event_id')
            ->first();

        $this->assertNotNull($finalizedEvent);
        $this->assertSame('WARN', $finalizedEvent->severity);
        $this->assertSame('RUN_LOCK_CONFLICT', $finalizedEvent->reason_code);
        $this->assertSame('Current publication pointer resolution mismatch after finalize.', (string) $finalizedEvent->message);

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'CORRECTION_PUBLISHED')
                ->exists()
        );
    }



    public function test_run_daily_approved_correction_with_pointer_publication_version_mismatch_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToPublicationWithDifferentVersionForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-publication-version-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected pointer/publication publication_version mismatch to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $unexpectedRun = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($unexpectedRun);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);
        $this->assertSame(1, (int) $publication->publication_version);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('SUCCESS', $baselineRun->terminal_status);
        $this->assertSame('READABLE', $baselineRun->publishability_state);
        $this->assertSame(1, (int) $baselineRun->is_current_publication);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);
        $this->assertSame(2, (int) $pointer->publication_version);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }

    public function test_run_daily_approved_correction_with_pointer_run_id_mismatch_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerToPublicationWithDifferentRunIdForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-run-id-mismatch', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected pointer/publication run_id mismatch to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $unexpectedRun = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->whereNotIn('run_id', [90, 91])
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($unexpectedRun);

                $this->assertSame(
            2,
            (int) DB::table('eod_runs')
                ->where('trade_date_requested', '2026-03-20')
                ->count()
        );

        $incidentRun = DB::table('eod_runs')->where('run_id', 91)->first();

        $this->assertNotNull($incidentRun);
        $this->assertSame('SUCCESS', $incidentRun->terminal_status);
        $this->assertSame('READABLE', $incidentRun->publishability_state);
        $this->assertSame(1, (int) $incidentRun->is_current_publication);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);
        $this->assertSame(90, (int) $publication->run_id);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('SUCCESS', $baselineRun->terminal_status);
        $this->assertSame('READABLE', $baselineRun->publishability_state);
        $this->assertSame(1, (int) $baselineRun->is_current_publication);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(91, (int) $pointer->run_id);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }



    public function test_run_daily_approved_correction_with_pointer_to_missing_publication_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedBaselinePointerWithoutPublicationForTradeDate('2026-03-20');

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-missing-publication', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected pointer to missing publication to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $this->assertNull(
            DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->first()
        );

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(999, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }

    public function test_run_daily_approved_correction_with_pointer_to_publication_missing_sealed_at_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        DB::table('eod_publications')
            ->where('publication_id', 1)
            ->update([
                'sealed_at' => null,
                'updated_at' => '2026-03-20 17:22:30',
            ]);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-publication-missing-sealed-at', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected baseline publication missing sealed_at to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('SEALED', $publication->seal_state);
        $this->assertSame(1, (int) $publication->is_current);
        $this->assertNull($publication->sealed_at);

        $baselineRun = DB::table('eod_runs')->where('run_id', 90)->first();
        $this->assertNotNull($baselineRun);
        $this->assertSame('SUCCESS', $baselineRun->terminal_status);
        $this->assertSame('READABLE', $baselineRun->publishability_state);
        $this->assertSame(1, (int) $baselineRun->is_current_publication);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }

    public function test_run_daily_approved_correction_with_pointer_to_unsealed_non_current_publication_rejects_before_run_creation_and_preserves_approval_state(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-27', '2026-03-19', 1, 100.0, 1000);
        $this->seedMalformedBaselinePointerForTradeDate('2026-03-20', 1, 120.0, 'UNSEALED', 0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 134,
            'high' => 139,
            'low' => 133,
            'close' => 138,
            'volume' => 2900,
            'adj_close' => 138,
            'captured_at' => '2026-03-20T17:25:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'recompute-with-pointer-to-unsealed-baseline', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        try {
            $this->makePipeline()->runDaily('2026-03-20', 'manual_file', $approved->correction_id);
            $this->fail('Expected malformed baseline pointer/current publication state to reject approved correction before run creation.');
        } catch (RuntimeException $e) {
            $this->assertSame(
                'Correction requires an existing current sealed publication baseline resolved from current pointer/current publication for target trade date.',
                $e->getMessage()
            );
        }

        $run = DB::table('eod_runs')
            ->where('trade_date_requested', '2026-03-20')
            ->where('run_id', '!=', 90)
            ->orderByDesc('run_id')
            ->first();

        $this->assertNull($run);

        $persistedCorrection = DB::table('eod_dataset_corrections')
            ->where('correction_id', $approved->correction_id)
            ->first();

        $this->assertNotNull($persistedCorrection);
        $this->assertSame('APPROVED', $persistedCorrection->status);
        $this->assertNull($persistedCorrection->prior_run_id);
        $this->assertNull($persistedCorrection->new_run_id);
        $this->assertNull($persistedCorrection->published_at);
        $this->assertNull($persistedCorrection->final_outcome_note);

        $publication = DB::table('eod_publications')
            ->where('trade_date', '2026-03-20')
            ->where('publication_id', 1)
            ->first();

        $this->assertNotNull($publication);
        $this->assertSame('UNSEALED', $publication->seal_state);
        $this->assertSame(0, (int) $publication->is_current);

        $pointer = DB::table('eod_current_publication_pointer')
            ->where('trade_date', '2026-03-20')
            ->first();

        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame(90, (int) $pointer->run_id);

        $this->assertSame(
            1,
            (int) DB::table('eod_publications')
                ->where('trade_date', '2026-03-20')
                ->count()
        );

        $this->assertSame(
            0,
            DB::table('eod_run_events')
                ->where('payload_json', 'like', '%"correction_id":'.$approved->correction_id.'%')
                ->count()
        );
    }



    public function test_manual_file_import_only_writes_candidate_bars_without_finalize_or_pointer_switch(): void
    {
        $this->seedTicker(1, 'BBCA');

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $run = $this->makePipeline()->importDaily('2026-03-20', 'manual_file');
        $publication = DB::table('eod_publications')->where('run_id', $run->run_id)->first();

        $this->assertSame('INGEST_BARS', $run->stage);
        $this->assertSame('RUNNING', $run->lifecycle_state);
        $this->assertNull($run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertNull($run->coverage_gate_state);
        $this->assertNull($run->bars_batch_hash);
        $this->assertNull($run->sealed_at);
        $this->assertNull($run->final_reason_code);
        $this->assertSame(1, (int) $run->bars_rows_written);

        $this->assertNotNull($publication);
        $this->assertSame('UNSEALED', $publication->seal_state);
        $this->assertSame(0, (int) $publication->is_current);
        $this->assertNull($publication->sealed_at);

        $this->assertSame(1, DB::table('eod_bars')->where('run_id', $run->run_id)->count());
        $this->assertSame(0, DB::table('eod_indicators')->where('run_id', $run->run_id)->count());
        $this->assertSame(0, DB::table('eod_eligibility')->where('run_id', $run->run_id)->count());
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());

        $this->assertTrue(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('stage', 'INGEST_BARS')
                ->where('event_type', 'STAGE_COMPLETED')
                ->exists()
        );

        $this->assertFalse(
            DB::table('eod_run_events')
                ->where('run_id', $run->run_id)
                ->where('event_type', 'RUN_FINALIZED')
                ->exists()
        );
    }

    public function test_manual_file_promote_from_imported_partial_dataset_enforces_coverage_gate_and_does_not_switch_pointer(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedTicker(2, 'BBRI');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 2, 80.0, 900);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $pipeline = $this->makePipeline();
        $importRun = $pipeline->importDaily('2026-03-20', 'manual_file');
        $promoteRun = $pipeline->promoteDaily('2026-03-20', 'manual_file', $importRun->run_id);
        $event = DB::table('eod_run_events')
            ->where('run_id', $promoteRun->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->first();
        $payload = json_decode((string) $event->event_payload_json, true);
        $candidate = DB::table('eod_publications')->where('run_id', $promoteRun->run_id)->first();

        $this->assertSame('FAILED', $promoteRun->terminal_status);
        $this->assertSame('NOT_READABLE', $promoteRun->publishability_state);
        $this->assertSame('FAIL', $promoteRun->coverage_gate_state);
        $this->assertSame('full_publish', $promoteRun->promote_mode);
        $this->assertSame('current_replace', $promoteRun->publish_target);
        $this->assertSame(2, (int) $promoteRun->coverage_universe_count);
        $this->assertSame(1, (int) $promoteRun->coverage_available_count);
        $this->assertSame(1, (int) $promoteRun->coverage_missing_count);
        $this->assertSame('RUN_PARTIAL_DATA', $event->reason_code);
        $this->assertSame('RUN_PARTIAL_DATA', $payload['coverage_reason_code']);
        $this->assertSame(2, $payload['coverage_universe_count']);
        $this->assertSame(1, $payload['coverage_available_count']);
        $this->assertSame(1, $payload['coverage_missing_count']);

        $this->assertNotNull($candidate);
        $this->assertSame(0, (int) $candidate->is_current);
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());
        $this->assertSame(0, DB::table('eod_publications')->where('trade_date', '2026-03-20')->where('is_current', 1)->count());
    }

    public function test_run_daily_full_coverage_persists_finalize_coverage_payload_and_readable_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedTicker(2, 'BBRI');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 2, 80.0, 900);

        $this->writeBarsFixture('2026-03-20', [
            [
                'ticker_code' => 'BBCA',
                'trade_date' => '2026-03-20',
                'open' => 121,
                'high' => 125,
                'low' => 120,
                'close' => 124,
                'volume' => 2000,
                'adj_close' => 124,
                'captured_at' => '2026-03-20T17:20:00+07:00',
            ],
            [
                'ticker_code' => 'BBRI',
                'trade_date' => '2026-03-20',
                'open' => 91,
                'high' => 94,
                'low' => 90,
                'close' => 93,
                'volume' => 1800,
                'adj_close' => 93,
                'captured_at' => '2026-03-20T17:21:00+07:00',
            ],
        ]);

        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file');
        $event = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->first();
        $payload = json_decode((string) $event->event_payload_json, true);

        $this->assertSame('SUCCESS', $run->terminal_status);
        $this->assertSame('READABLE', $run->publishability_state);
        $this->assertSame('PASS', $run->coverage_gate_state);
        $this->assertSame(2, (int) $run->coverage_available_count);
        $this->assertSame(2, (int) $run->coverage_universe_count);
        $this->assertSame(0, (int) $run->coverage_missing_count);
        $this->assertSame('coverage_gate_v1', (string) $run->coverage_contract_version);
        $this->assertNotNull($event);
        $this->assertNull($event->reason_code);
        $this->assertSame('PASS', $payload['coverage_gate_state']);
        $this->assertSame('COVERAGE_THRESHOLD_MET', $payload['coverage_reason_code']);
        $this->assertSame(2, $payload['coverage_available_count']);
        $this->assertSame(2, $payload['coverage_universe_count']);
        $this->assertSame(0, $payload['coverage_missing_count']);
        $this->assertSame('coverage_gate_v1', $payload['coverage_contract_version']);
        $this->assertSame('2026-03-20', $payload['trade_date_effective']);
    }

    public function test_run_daily_low_coverage_with_fallback_holds_requested_date_and_preserves_old_readable_publication(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedTicker(2, 'BBRI');
        $this->seedHistoricalBars('2026-02-27', '2026-03-18', 1, 100.0, 1000);
        $this->seedHistoricalBars('2026-02-27', '2026-03-18', 2, 80.0, 900);
        $this->seedReadableFallbackPublication('2026-03-19', 80, 11);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file');
        $event = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->first();
        $payload = json_decode((string) $event->event_payload_json, true);

        $this->assertSame('HELD', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('FAIL', $run->quality_gate_state);
        $this->assertSame('FAIL', $run->coverage_gate_state);
        $this->assertSame('2026-03-19', $run->trade_date_effective);
        $this->assertSame('RUN_PARTIAL_DATA', $event->reason_code);
        $this->assertSame('RUN_PARTIAL_DATA', $payload['coverage_reason_code']);
        $this->assertSame(1, $payload['coverage_available_count']);
        $this->assertSame(2, $payload['coverage_universe_count']);
        $this->assertSame(1, $payload['coverage_missing_count']);
        $this->assertSame(11, (int) $payload['fallback_publication_id']);
        $this->assertSame('2026-03-19', $payload['fallback_trade_date']);
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());

        $fallbackPointer = DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-19')->first();
        $fallbackPublication = DB::table('eod_publications')->where('publication_id', 11)->first();
        $fallbackRun = DB::table('eod_runs')->where('run_id', 80)->first();

        $this->assertNotNull($fallbackPointer);
        $this->assertSame(11, (int) $fallbackPointer->publication_id);
        $this->assertNotNull($fallbackPublication);
        $this->assertSame(1, (int) $fallbackPublication->is_current);
        $this->assertNotNull($fallbackRun);
        $this->assertSame('SUCCESS', $fallbackRun->terminal_status);
        $this->assertSame('READABLE', $fallbackRun->publishability_state);
        $this->assertSame(1, (int) $fallbackRun->is_current_publication);
    }

    public function test_run_daily_low_coverage_without_fallback_finishes_not_readable_and_emits_coverage_reason_code(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedTicker(2, 'BBRI');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 2, 80.0, 900);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 121,
            'high' => 125,
            'low' => 120,
            'close' => 124,
            'volume' => 2000,
            'adj_close' => 124,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $run = $this->makePipeline()->runDaily('2026-03-20', 'manual_file');
        $event = DB::table('eod_run_events')
            ->where('run_id', $run->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->first();
        $payload = json_decode((string) $event->event_payload_json, true);
        $publication = DB::table('eod_publications')->where('run_id', $run->run_id)->first();

        $this->assertSame('FAILED', $run->terminal_status);
        $this->assertSame('NOT_READABLE', $run->publishability_state);
        $this->assertSame('FAIL', $run->quality_gate_state);
        $this->assertSame('FAIL', $run->coverage_gate_state);
        $this->assertNull($run->trade_date_effective);
        $this->assertSame('RUN_PARTIAL_DATA', $event->reason_code);
        $this->assertSame('RUN_PARTIAL_DATA', $payload['coverage_reason_code']);
        $this->assertSame(1, $payload['coverage_available_count']);
        $this->assertSame(2, $payload['coverage_universe_count']);
        $this->assertSame(1, $payload['coverage_missing_count']);
        $this->assertNotNull($publication);
        $this->assertSame(0, (int) $publication->is_current);
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());
    }

    public function test_finalize_blocked_without_universe_stays_not_readable_and_emits_blocked_coverage_reason_code(): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 55,
            'trade_date_requested' => '2026-03-20',
            'trade_date_effective' => null,
            'lifecycle_state' => 'RUNNING',
            'terminal_status' => null,
            'quality_gate_state' => 'PENDING',
            'publishability_state' => 'NOT_READABLE',
            'stage' => 'SEAL',
            'source' => 'manual_file',
            'coverage_universe_count' => 0,
            'coverage_available_count' => 0,
            'coverage_missing_count' => 0,
            'coverage_ratio' => null,
            'coverage_min_threshold' => '0.9800',
            'coverage_gate_state' => 'NOT_EVALUABLE',
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ticker_master_active_on_trade_date',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'not-evaluable-finalize',
            'bars_batch_hash' => 'bars-ne',
            'indicators_batch_hash' => 'ind-ne',
            'eligibility_batch_hash' => 'elig-ne',
            'config_version' => 'v1',
            'publication_version' => 1,
            'is_current_publication' => 0,
            'sealed_at' => '2026-03-24 23:06:08',
            'sealed_by' => 'system',
            'seal_note' => 'not-evaluable-finalize',
            'started_at' => '2026-03-24 23:00:00',
            'finished_at' => null,
            'created_at' => '2026-03-24 23:00:00',
            'updated_at' => '2026-03-24 23:06:08',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 21,
            'trade_date' => '2026-03-20',
            'run_id' => 55,
            'publication_version' => 1,
            'is_current' => 0,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-ne',
            'indicators_batch_hash' => 'ind-ne',
            'eligibility_batch_hash' => 'elig-ne',
            'sealed_at' => '2026-03-24 23:06:08',
            'created_at' => '2026-03-24 23:06:08',
            'updated_at' => '2026-03-24 23:06:08',
        ]);

        $finalizedRun = $this->makePipeline()->completeFinalize(
            new App\Application\MarketData\DTOs\MarketDataStageInput('2026-03-20', 'manual_file', 55, 'FINALIZE', null)
        );

        $event = DB::table('eod_run_events')
            ->where('run_id', $finalizedRun->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->first();
        $payload = json_decode((string) $event->event_payload_json, true);
        $publication = DB::table('eod_publications')->where('publication_id', 21)->first();

        $this->assertSame('FAILED', $finalizedRun->terminal_status);
        $this->assertSame('NOT_READABLE', $finalizedRun->publishability_state);
        $this->assertSame('BLOCKED', $finalizedRun->quality_gate_state);
        $this->assertSame('NOT_EVALUABLE', $finalizedRun->coverage_gate_state);
        $this->assertNull($finalizedRun->trade_date_effective);
        $this->assertSame('RUN_COVERAGE_NOT_EVALUABLE', $event->reason_code);
        $this->assertSame('RUN_COVERAGE_NOT_EVALUABLE', $payload['coverage_reason_code']);
        $this->assertSame(0, $payload['coverage_universe_count']);
        $this->assertSame(0, $payload['coverage_available_count']);
        $this->assertSame(0, $payload['coverage_missing_count']);

        $this->assertSame('coverage_gate_v1', $payload['coverage_contract_version']);
        $this->assertSame(0, (int) $publication->is_current);
        $this->assertNull(DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first());
    }

    public function test_promote_single_day_repair_candidate_first_execution_marks_metadata_and_keeps_current_publication_non_current(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 131,
            'high' => 135,
            'low' => 130,
            'close' => 134,
            'volume' => 2400,
            'adj_close' => 134,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'repair-first-pass', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $pipeline = $this->makePipeline();
        $importRun = $pipeline->importSingleDay('2026-03-20', 'manual_file');
        $repairRun = $pipeline->promoteSingleDay('2026-03-20', 'manual_file', $importRun->run_id, $approved->correction_id, 'repair_candidate');

        $correctionRow = DB::table('eod_dataset_corrections')->where('correction_id', $approved->correction_id)->first();
        $candidatePublication = DB::table('eod_publications')->where('run_id', $repairRun->run_id)->first();
        $pointer = DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first();
        $finalizedEvent = DB::table('eod_run_events')
            ->where('run_id', $repairRun->run_id)
            ->where('event_type', 'RUN_FINALIZED')
            ->first();
        $payload = json_decode((string) $finalizedEvent->event_payload_json, true);

        $this->assertSame('SUCCESS', $repairRun->terminal_status);
        $this->assertSame('NOT_READABLE', $repairRun->publishability_state);
        $this->assertSame('repair_candidate', $repairRun->promote_mode);
        $this->assertSame('repair_candidate', $repairRun->publish_target);
        $this->assertSame('REPAIR_EXECUTED', $correctionRow->status);
        $this->assertSame(1, (int) $correctionRow->execution_count);
        $this->assertSame((int) $repairRun->run_id, (int) $correctionRow->new_run_id);
        $this->assertNotNull($correctionRow->last_executed_at);
        $this->assertNull($correctionRow->current_consumed_at);
        $this->assertNotNull($candidatePublication);
        $this->assertSame(0, (int) $candidatePublication->is_current);
        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
        $this->assertSame('RUN_REPAIR_CANDIDATE_PARTIAL', $finalizedEvent->reason_code);
        $this->assertSame('REPAIR_CANDIDATE', $payload['correction_outcome']);
    }

    public function test_promote_single_day_repair_candidate_rerun_increments_execution_count_and_preserves_current_pointer(): void
    {
        $this->seedTicker(1, 'BBCA');
        $this->seedHistoricalBars('2026-02-28', '2026-03-19', 1, 100.0, 1000);
        $this->seedCurrentPublicationBaselineForTradeDate('2026-03-20', 1, 120.0);

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 141,
            'high' => 146,
            'low' => 140,
            'close' => 145,
            'volume' => 2600,
            'adj_close' => 145,
            'captured_at' => '2026-03-20T17:20:00+07:00',
        ]]);

        $corrections = new EodCorrectionRepository();
        $request = $corrections->createRequest('2026-03-20', 'READABILITY_FIX', 'repair-rerun', 'system');
        $approved = $corrections->approve($request->correction_id, 'reviewer');

        $pipeline = $this->makePipeline();
        $firstImportRun = $pipeline->importSingleDay('2026-03-20', 'manual_file');
        $firstRepairRun = $pipeline->promoteSingleDay('2026-03-20', 'manual_file', $firstImportRun->run_id, $approved->correction_id, 'repair_candidate');

        $this->writeBarsFixture('2026-03-20', [[
            'ticker_code' => 'BBCA',
            'trade_date' => '2026-03-20',
            'open' => 143,
            'high' => 148,
            'low' => 142,
            'close' => 147,
            'volume' => 2800,
            'adj_close' => 147,
            'captured_at' => '2026-03-20T17:30:00+07:00',
        ]]);

        $secondImportRun = $pipeline->importSingleDay('2026-03-20', 'manual_file');
        $secondRepairRun = $pipeline->promoteSingleDay('2026-03-20', 'manual_file', $secondImportRun->run_id, $approved->correction_id, 'incremental');

        $correctionRow = DB::table('eod_dataset_corrections')->where('correction_id', $approved->correction_id)->first();
        $firstCandidate = DB::table('eod_publications')->where('run_id', $firstRepairRun->run_id)->first();
        $secondCandidate = DB::table('eod_publications')->where('run_id', $secondRepairRun->run_id)->first();
        $pointer = DB::table('eod_current_publication_pointer')->where('trade_date', '2026-03-20')->first();

        $this->assertSame('SUCCESS', $firstRepairRun->terminal_status);
        $this->assertSame('SUCCESS', $secondRepairRun->terminal_status);
        $this->assertSame('NOT_READABLE', $secondRepairRun->publishability_state);
        $this->assertSame('repair_candidate', $secondRepairRun->promote_mode);
        $this->assertSame('repair_candidate', $secondRepairRun->publish_target);
        $this->assertSame('REPAIR_EXECUTED', $correctionRow->status);
        $this->assertSame(2, (int) $correctionRow->execution_count);
        $this->assertSame((int) $secondRepairRun->run_id, (int) $correctionRow->new_run_id);
        $this->assertNotNull($correctionRow->last_executed_at);
        $this->assertNull($correctionRow->current_consumed_at);
        $this->assertNotNull($firstCandidate);
        $this->assertNotNull($secondCandidate);
        $this->assertSame(0, (int) $firstCandidate->is_current);
        $this->assertSame(0, (int) $secondCandidate->is_current);
        $this->assertNotSame((int) $firstRepairRun->run_id, (int) $secondRepairRun->run_id);
        $this->assertNotNull($pointer);
        $this->assertSame(1, (int) $pointer->publication_id);
    }

    private function deleteDirectory(string $path): void
    {
        if (! is_dir($path)) {
            return;
        }

        $items = scandir($path);
        if (! is_array($items)) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $fullPath = $path.DIRECTORY_SEPARATOR.$item;
            if (is_dir($fullPath)) {
                $this->deleteDirectory($fullPath);
                continue;
            }

            @unlink($fullPath);
        }

        @rmdir($path);
    }

    private function makeBackfillService(): MarketDataBackfillService
    {
        return new MarketDataBackfillService(new App\Infrastructure\Persistence\MarketData\MarketCalendarRepository(), $this->makePipeline());
    }

    private function makeBackfillServiceWithApiFetcher(callable $fetcher): MarketDataBackfillService
    {
        return new MarketDataBackfillService(new App\Infrastructure\Persistence\MarketData\MarketCalendarRepository(), $this->makePipelineWithApiFetcher($fetcher));
    }

    private function makePipeline(): MarketDataPipelineService
    {
        return $this->makePipelineWithOverrides(new EodPublicationRepository(), new EodArtifactRepository());
    }

    private function makePipelineWithApiFetcher(callable $fetcher): MarketDataPipelineService
    {
        return $this->makePipelineWithOverrides(new EodPublicationRepository(), new EodArtifactRepository(), $fetcher);
    }

    private function makePipelineWithPublications(EodPublicationRepository $publications): MarketDataPipelineService
    {
        return $this->makePipelineWithOverrides($publications, new EodArtifactRepository());
    }

    private function makePipelineWithArtifacts(EodArtifactRepository $artifacts): MarketDataPipelineService
    {
        return $this->makePipelineWithOverrides(new EodPublicationRepository(), $artifacts);
    }

    private function makePipelineWithOverrides(EodPublicationRepository $publications, EodArtifactRepository $artifacts, callable $apiFetcher = null): MarketDataPipelineService
    {
        $runs = new EodRunRepository();
        $tickers = new TickerMasterRepository();

        $bars = new EodBarsIngestService(
            new LocalFileEodBarsAdapter(),
            new PublicApiEodBarsAdapter($apiFetcher ?: function () {
                throw new RuntimeException('API source not expected in sqlite integration test.');
            }),
            $tickers,
            $artifacts,
            $publications
        );

        $indicators = new EodIndicatorsComputeService(
            $artifacts,
            $publications,
            new IndicatorVectorService()
        );

        $eligibility = new EodEligibilityBuildService(
            $tickers,
            $artifacts,
            $publications,
            new EligibilityDecisionService()
        );

        return new MarketDataPipelineService(
            $runs,
            $bars,
            $indicators,
            $eligibility,
            $publications,
            new EodCorrectionRepository(),
            $artifacts,
            new DeterministicHashService(),
            new FinalizeDecisionService(),
            new PublicationDiffService(),
            new PublicationFinalizeOutcomeService(),
            new CoverageGateEvaluator(new TickerMasterRepository(), $artifacts)
        );
    }

    private function makeEvidenceExporter(): MarketDataEvidenceExportService
    {
        return new MarketDataEvidenceExportService(
            new App\Infrastructure\Persistence\MarketData\EodEvidenceRepository(),
            new EodPublicationRepository(),
            new EodCorrectionRepository()
        );
    }

    private function seedTicker(int $tickerId, string $tickerCode): void
    {
        DB::table('tickers')->insert([
            'ticker_id' => $tickerId,
            'ticker_code' => $tickerCode,
            'is_active' => 1,
            'listed_date' => '2020-01-01',
            'delisted_date' => null,
        ]);
    }

    private function seedMarketCalendarRange(string $startDate, string $endDate): void
    {
        $date = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);

        while ($date->lessThanOrEqualTo($end)) {
            DB::table('market_calendar')->insert([
                'cal_date' => $date->toDateString(),
                'is_trading_day' => in_array($date->dayOfWeekIso, [6, 7], true) ? 0 : 1,
                'source' => 'test_fixture',
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString(),
            ]);
            $date->addDay();
        }
    }

    private function seedHistoricalBars(string $startDate, string $endDate, int $tickerId, float $startClose, int $startVolume): void
    {
        $date = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);
        $close = $startClose;
        $volume = $startVolume;

        while ($date->lessThanOrEqualTo($end)) {
            DB::table('eod_bars')->insert([
                'trade_date' => $date->toDateString(),
                'ticker_id' => $tickerId,
                'open' => $close - 1,
                'high' => $close + 2,
                'low' => $close - 2,
                'close' => $close,
                'volume' => $volume,
                'adj_close' => $close,
                'source' => 'MANUAL_FILE',
                'run_id' => 1,
                'publication_id' => 0,
                'created_at' => Carbon::now()->toDateTimeString(),
            ]);

            $date->addDay();
            $close += 1;
            $volume += 10;
        }
    }


    private function seedBaselinePointerToDifferentTradeDatePublication(string $pointerTradeDate, string $publicationTradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $pointerTradeDate,
            'trade_date_effective' => $pointerTradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'trade-date-mismatch-baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'trade-date-mismatch-baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $publicationTradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $pointerTradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->updateOrInsert(
            [
                'trade_date' => $publicationTradeDate,
                'ticker_id' => $tickerId,
            ],
            [
                'open' => $close,
                'high' => $close,
                'low' => $close,
                'close' => $close,
                'volume' => 1000,
                'adj_close' => $close,
                'source' => 'MANUAL_FILE',
                'run_id' => 90,
                'publication_id' => 1,
                'created_at' => Carbon::now()->toDateTimeString(),
            ]
        );

        DB::table('eod_indicators')->insert([
            'trade_date' => $publicationTradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $publicationTradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => null,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }


    private function seedBaselinePointerToPublicationWithRunRequestedTradeDateMismatch(string $tradeDate, string $runTradeDateRequested, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $runTradeDateRequested,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'run-requested-trade-date-mismatch-baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'run-requested-trade-date-mismatch-baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => null,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }
    private function seedBaselinePointerToPublicationWithMissingRunForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => null,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }


    private function seedBaselinePointerToNonReadableRunPublicationForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'HELD',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'NOT_READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 1,
            'notes' => 'non-readable-baseline-run',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_version' => 1,
            'is_current_publication' => 0,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'non-readable-baseline-run',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => null,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }



    private function seedBaselinePointerToSealedPublicationMarkedNonCurrentForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'sealed-publication-marked-non-current',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'sealed-publication-marked-non-current',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 0,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => 'baseline',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }



    private function seedBaselinePointerToReadableRunMarkedNonCurrentForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'readable-run-marked-non-current',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_version' => 1,
            'is_current_publication' => 0,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'readable-run-marked-non-current',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => 'baseline',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }


    private function seedBaselinePointerToPublicationWithDifferentVersionForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'pointer-publication-version-mismatch-baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'pointer-publication-version-mismatch-baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:20:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 2,
            'sealed_at' => '2026-03-20 17:20:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => 'baseline',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }

    private function seedBaselinePointerToPublicationWithDifferentRunIdForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'pointer-run-id-mismatch-baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'pointer-run-id-mismatch-baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_runs')->insert([
            'run_id' => 91,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'pointer-run-id-mismatch-incident',
            'bars_batch_hash' => 'bars-incident',
            'indicators_batch_hash' => 'ind-incident',
            'eligibility_batch_hash' => 'elig-incident',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:21:00',
            'sealed_by' => 'system',
            'seal_note' => 'pointer-run-id-mismatch-incident',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:21:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:21:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 91,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => 'baseline',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }

    private function seedBaselinePointerWithoutPublicationForTradeDate(string $tradeDate): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'missing-publication-baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'missing-publication-baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 999,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);
    }

    private function seedMalformedBaselinePointerForTradeDate(string $tradeDate, int $tickerId, float $close, string $sealState = 'UNSEALED', int $isCurrent = 0): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'malformed-baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_version' => 1,
            'is_current_publication' => $isCurrent,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'malformed-baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => $isCurrent,
            'supersedes_publication_id' => null,
            'seal_state' => $sealState,
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => $sealState === 'SEALED' ? '2026-03-20 17:20:00' : null,
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close,
            'high' => $close,
            'low' => $close,
            'close' => $close,
            'volume' => 1000,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => config('market_data.indicators.set_version'),
            'dv20_idr' => 100000000,
            'atr14_pct' => 0.02,
            'vol_ratio' => 1.1,
            'roc20' => 0.03,
            'hh20' => $close,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => 'baseline',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);
    }

    private function seedCurrentPublicationBaselineForTradeDate(string $tradeDate, int $tickerId, float $close): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => 90,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'baseline',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'config_version' => 'v1',
            'publication_id' => 1,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'baseline',
            'started_at' => '2026-03-20 17:00:00',
            'finished_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => 1,
            'trade_date' => $tradeDate,
            'run_id' => 90,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-old',
            'indicators_batch_hash' => 'ind-old',
            'eligibility_batch_hash' => 'elig-old',
            'sealed_at' => '2026-03-20 17:20:00',
            'created_at' => '2026-03-20 17:00:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => 1,
            'run_id' => 90,
            'publication_version' => 1,
            'sealed_at' => '2026-03-20 17:20:00',
            'updated_at' => '2026-03-20 17:20:00',
        ]);

        DB::table('eod_bars')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'open' => $close - 1,
            'high' => $close + 2,
            'low' => $close - 2,
            'close' => $close,
            'volume' => 1500,
            'adj_close' => $close,
            'source' => 'MANUAL_FILE',
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => '2026-03-20 17:00:00',
        ]);

        DB::table('eod_indicators')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'is_valid' => 1,
            'invalid_reason_code' => null,
            'indicator_set_version' => 'v1',
            'dv20_idr' => 1000000,
            'atr14_pct' => 0.01,
            'vol_ratio' => 1.0,
            'roc20' => 0.02,
            'hh20' => $close + 2,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => '2026-03-20 17:00:00',
        ]);

        DB::table('eod_eligibility')->insert([
            'trade_date' => $tradeDate,
            'ticker_id' => $tickerId,
            'eligible' => 1,
            'reason_code' => null,
            'run_id' => 90,
            'publication_id' => 1,
            'created_at' => '2026-03-20 17:00:00',
        ]);
    }


    private function seedReadableFallbackPublication(string $tradeDate, int $runId, int $publicationId): void
    {
        DB::table('eod_runs')->insert([
            'run_id' => $runId,
            'trade_date_requested' => $tradeDate,
            'trade_date_effective' => $tradeDate,
            'lifecycle_state' => 'COMPLETED',
            'terminal_status' => 'SUCCESS',
            'quality_gate_state' => 'PASS',
            'publishability_state' => 'READABLE',
            'stage' => 'FINALIZE',
            'source' => 'manual_file',
            'coverage_ratio' => '1.0000',
            'coverage_gate_state' => 'PASS',
            'coverage_min_threshold' => '0.9800',
            'coverage_universe_count' => 1,
            'coverage_available_count' => 1,
            'coverage_missing_count' => 0,
            'coverage_threshold_mode' => 'MIN_RATIO',
            'coverage_universe_basis' => 'ACTIVE_TICKER_MASTER_FOR_TRADE_DATE',
            'coverage_contract_version' => 'coverage_gate_v1',
            'bars_rows_written' => 1,
            'indicators_rows_written' => 1,
            'eligibility_rows_written' => 1,
            'invalid_bar_count' => 0,
            'invalid_indicator_count' => 0,
            'hard_reject_count' => 0,
            'warning_count' => 0,
            'notes' => 'fallback',
            'bars_batch_hash' => 'bars-fallback',
            'indicators_batch_hash' => 'ind-fallback',
            'eligibility_batch_hash' => 'elig-fallback',
            'config_version' => 'v1',
            'publication_id' => $publicationId,
            'publication_version' => 1,
            'is_current_publication' => 1,
            'sealed_at' => $tradeDate.' 17:20:00',
            'sealed_by' => 'system',
            'seal_note' => 'fallback',
            'started_at' => $tradeDate.' 17:00:00',
            'finished_at' => $tradeDate.' 17:20:00',
            'created_at' => $tradeDate.' 17:00:00',
            'updated_at' => $tradeDate.' 17:20:00',
        ]);

        DB::table('eod_publications')->insert([
            'publication_id' => $publicationId,
            'trade_date' => $tradeDate,
            'run_id' => $runId,
            'publication_version' => 1,
            'is_current' => 1,
            'supersedes_publication_id' => null,
            'seal_state' => 'SEALED',
            'bars_batch_hash' => 'bars-fallback',
            'indicators_batch_hash' => 'ind-fallback',
            'eligibility_batch_hash' => 'elig-fallback',
            'sealed_at' => $tradeDate.' 17:20:00',
            'created_at' => $tradeDate.' 17:00:00',
            'updated_at' => $tradeDate.' 17:20:00',
        ]);

        DB::table('eod_current_publication_pointer')->insert([
            'trade_date' => $tradeDate,
            'publication_id' => $publicationId,
            'run_id' => $runId,
            'publication_version' => 1,
            'sealed_at' => $tradeDate.' 17:20:00',
            'updated_at' => $tradeDate.' 17:20:00',
        ]);
    }

    private function writeBarsFixture(string $tradeDate, array $rows): void
    {
        file_put_contents(
            $this->fixtureDir.DIRECTORY_SEPARATOR.$tradeDate.'.json',
            json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
        );
    }
}

class ThrowingSealPublicationRepository extends EodPublicationRepository
{
    private string $message;

    public function __construct(string $message)
    {
        $this->message = $message;
    }

    public function sealCandidatePublication(App\Models\EodRun $run, $sealedBy, $sealNote = null)
    {
        throw new RuntimeException($this->message);
    }
}

class BaselineMismatchPromotionPublicationRepository extends EodPublicationRepository
{
    private int $conflictingPublicationId;

    private int $conflictingRunId;

    private int $conflictingPublicationVersion;

    public function __construct(int $conflictingPublicationId, int $conflictingRunId, int $conflictingPublicationVersion)
    {
        $this->conflictingPublicationId = $conflictingPublicationId;
        $this->conflictingRunId = $conflictingRunId;
        $this->conflictingPublicationVersion = $conflictingPublicationVersion;
    }

    public function promoteCandidateToCurrent(App\Models\EodRun $run, $priorPublicationId = null, $forceReplace = false)
    {
        throw new RuntimeException(
            sprintf(
                'Correction baseline no longer matches current publication pointer. expected_prior_publication_id=%d conflicting_publication_id=%d conflicting_run_id=%d conflicting_publication_version=%d',
                (int) $priorPublicationId,
                $this->conflictingPublicationId,
                $this->conflictingRunId,
                $this->conflictingPublicationVersion
            )
        );
    }
}

class ThrowingPromotionPublicationRepository extends EodPublicationRepository
{
    private string $message;

    public function __construct(string $message)
    {
        $this->message = $message;
    }

    public function promoteCandidateToCurrent(App\Models\EodRun $run, $priorPublicationId = null, $forceReplace = false)
    {
        throw new RuntimeException($this->message);
    }
}
class PostSwitchResolutionMismatchPublicationRepository extends EodPublicationRepository
{
    public function promoteCandidateToCurrent(App\Models\EodRun $run, $priorPublicationId = null, $forceReplace = false)
    {
        $candidate = parent::promoteCandidateToCurrent($run, $priorPublicationId, $forceReplace);

        DB::table('eod_publications')
            ->where('publication_id', $candidate->publication_id)
            ->update([
                'is_current' => 0,
            ]);

        return $candidate;
    }
}

class ThrowingHistoryPromotionArtifactRepository extends EodArtifactRepository
{
    private string $message;

    public function __construct(string $message)
    {
        $this->message = $message;
    }

    public function promotePublicationHistoryToCurrent($tradeDate, $publicationId, $runId)
    {
        throw new RuntimeException($this->message);
    }
}

<?php

use PHPUnit\Framework\TestCase;

class CoveragePolicyDocsStaticGuardTest extends TestCase
{
    private function projectPath(string $path): string
    {
        return dirname(__DIR__, 3).DIRECTORY_SEPARATOR.str_replace('/', DIRECTORY_SEPARATOR, $path);
    }

    private function read(string $path): string
    {
        $fullPath = $this->projectPath($path);
        $this->assertFileExists($fullPath);

        return file_get_contents($fullPath);
    }

    public function test_active_test_matrix_uses_not_evaluable_instead_of_coverage_blocked(): void
    {
        $matrix = $this->read('docs/market_data/tests/PHPUNIT_TEST_MATRIX.md');

        $this->assertStringContainsString('expected = 0 -> coverage_gate_state = NOT_EVALUABLE', $matrix);
        $this->assertStringContainsString('quality_gate_state = BLOCKED', $matrix);
        $this->assertStringContainsString('publishability_state = NOT_READABLE', $matrix);
        $this->assertStringContainsString('coverage_gate_state=NOT_EVALUABLE', $matrix);
        $this->assertStringNotContainsString('expected = 0 → BLOCKED', $matrix);
        $this->assertStringNotContainsString('expected = 0 -> BLOCKED', $matrix);
        $this->assertStringNotContainsString('BLOCKED tanpa fallback', $matrix);
        $this->assertStringNotContainsString('FAILED + NOT_READABLE + BLOCKED', $matrix);
    }

    public function test_locked_schema_and_migration_normalize_legacy_blocked_coverage_state(): void
    {
        $schema = $this->read('docs/market_data/db/Database_Schema_MariaDB.sql');
        $metadata = $this->read('docs/market_data/db/DB_FIELDS_AND_METADATA.md');
        $migration = $this->read('database/migrations/2026_05_18_000001_normalize_legacy_blocked_coverage_gate_state.php');

        $this->assertStringContainsString("coverage_gate_state ENUM('PASS','FAIL','NOT_EVALUABLE') NULL", $schema);
        $this->assertStringNotContainsString("coverage_gate_state ENUM('PASS','FAIL','NOT_EVALUABLE','BLOCKED') NULL", $schema);
        $this->assertStringContainsString("Final allowed values: `PASS`, `FAIL`, `NOT_EVALUABLE`", $metadata);
        $this->assertStringContainsString("->where(\$column, 'BLOCKED')", $migration);
        $this->assertStringContainsString("->update([\$column => 'NOT_EVALUABLE'])", $migration);
        $this->assertStringContainsString("'eod_runs', 'coverage_gate_state'", $migration);
        $this->assertStringContainsString("'md_replay_daily_metrics', 'coverage_gate_state'", $migration);
        $this->assertStringContainsString("'md_replay_daily_metrics', 'expected_coverage_gate_state'", $migration);
        $this->assertStringNotContainsString('quality_gate_state', $migration);
    }

    public function test_market_data_coverage_min_threshold_stays_locked_to_098(): void
    {
        $config = $this->read('config/market_data.php');
        $envExample = $this->read('.env.example');
        $envTesting = $this->read('.env.testing');
        $contract = $this->read('docs/market_data/book/Coverage_Gate_Enforcement_Contract_LOCKED.md');

        $this->assertStringContainsString("env('MARKET_DATA_COVERAGE_MIN', 0.98)", $config);
        $this->assertStringContainsString('MARKET_DATA_COVERAGE_MIN=0.98', $envExample);
        $this->assertStringContainsString('MARKET_DATA_COVERAGE_MIN=0.98', $envTesting);
        $this->assertStringContainsString('MARKET_DATA_COVERAGE_MIN = 0.98', $contract);
        $this->assertStringNotContainsString('MARKET_DATA_COVERAGE_MIN=0.95', $envExample.$envTesting.$config.$contract);
    }

    public function test_evidence_replay_command_and_repository_boundaries_expose_legacy_raw_without_final_blocked_state(): void
    {
        $normalizer = $this->read('app/Application/MarketData/Services/CoverageGateStateNormalizer.php');
        $evidence = $this->read('app/Application/MarketData/Services/MarketDataEvidenceExportService.php');
        $replay = $this->read('app/Application/MarketData/Services/ReplayVerificationService.php');
        $command = $this->read('app/Console/Commands/MarketData/AbstractMarketDataCommand.php');
        $runRepository = $this->read('app/Infrastructure/Persistence/MarketData/EodRunRepository.php');
        $replayRepository = $this->read('app/Infrastructure/Persistence/MarketData/ReplayResultRepository.php');

        foreach (['PASS', 'FAIL', 'NOT_EVALUABLE', 'LEGACY_BLOCKED'] as $needle) {
            $this->assertStringContainsString($needle, $normalizer);
        }

        foreach ([$evidence, $replay, $command] as $surface) {
            $this->assertStringContainsString('CoverageGateStateNormalizer::normalize', $surface);
            $this->assertStringContainsString('legacy_coverage_gate_state_raw', $surface);
            $this->assertStringContainsString('RUN_COVERAGE_NOT_EVALUABLE', $surface);
        }

        $this->assertStringContainsString("unset(\$telemetry['coverage_gate_status'])", $runRepository);
        $this->assertStringContainsString("CoverageGateStateNormalizer::normalize(\$metric['coverage_gate_state'] ?? null)", $replayRepository);
        $this->assertStringContainsString("CoverageGateStateNormalizer::normalize(\$metric['expected_coverage_gate_state'] ?? null)", $replayRepository);
    }

    public function test_locked_contract_docs_require_coverage_aliases_and_legacy_raw_trace(): void
    {
        $coverage = $this->read('docs/market_data/book/Coverage_Gate_Enforcement_Contract_LOCKED.md');
        $eod = $this->read('docs/market_data/book/EOD_COVERAGE_GATE_CONTRACT_LOCKED.md');
        $evidence = $this->read('docs/market_data/ops/Audit_Evidence_Pack_Contract_LOCKED.md');

        foreach (['expected_bar_count', 'available_bar_count', 'missing_bar_count', 'legacy_coverage_gate_state_raw'] as $field) {
            $this->assertStringContainsString($field, $coverage.$eod.$evidence);
        }

        $this->assertStringContainsString('coverage_gate_state=NOT_EVALUABLE', $coverage.$eod);
        $this->assertStringContainsString('legacy input `BLOCKED` must not appear as final `coverage_gate_state`', $evidence);
    }
}

# Anomaly Report
- Requested date: 2026-02-18
- Effective date: null
- Status: FAILED
- Dominant anomaly: CORRECTION_PROMOTE_REQUIRED
- Consumer effect: fallback or no readable state
- Publication safety: requested date not proven readable as current sealed publication

# Anomaly Report
- Requested date: 2026-05-11
- Effective date: 2026-05-11
- Status: SUCCESS
- Dominant anomaly: PROMOTE_STARTED
- Consumer effect: requested date readable
- Publication safety: current sealed publication present

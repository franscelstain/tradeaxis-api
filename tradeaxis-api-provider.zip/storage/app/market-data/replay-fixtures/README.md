# Replay fixture smoke cases

These fixture packages are committed so runtime validation can be proven without hand-building ad hoc files.

## Cases
- `valid_case/`
  - expected to pass for a compatible completed run
  - now also proves empty expected reason-code counts remain aligned with actual replay proof
- `broken_manifest_case/`
  - expected to fail because `manifest.json` is missing required fields
- `missing_file_case/`
  - expected to fail because `manifest.files` declares `expected/missing.json` but that file is intentionally absent

## Commands

```bash
php artisan market-data:replay:verify <RUN_ID> storage/app/market_data/replay-fixtures/valid_case -vvv
php artisan market-data:replay:verify <RUN_ID> storage/app/market_data/replay-fixtures/broken_manifest_case -vvv
php artisan market-data:replay:verify <RUN_ID> storage/app/market_data/replay-fixtures/missing_file_case -vvv
```

If `missing_file_case` does not fail with `Replay fixture file missing: expected/missing.json`, treat that as a real implementation or environment defect and do not mark replay verification complete.


## Smoke suite
The built-in minimum smoke suite is executed through `market-data:replay:smoke {run_id}`.
Expected outcomes:
- `valid_case` => `MATCH`
- `reason_code_mismatch_case` => `MISMATCH`
- `broken_manifest_case` => `ERROR`
- `missing_file_case` => `ERROR`

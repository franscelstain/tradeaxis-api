# Operator manual file samples

This folder stores explicit operator-supplied market data files for `source_mode=manual_file`.

## Known-good CSV contract
Use comma-separated UTF-8 CSV with at least these headers:

- `ticker_code`
- `trade_date`
- `open`
- `high`
- `low`
- `close`
- `volume`

Optional but supported:

- `adj_close`
- `captured_at`
- `source_row_ref`

## Example command

```bash
php artisan market-data:backfill 2026-04-14 2026-04-14 --source_mode=manual_file --input_file=storage/app/market_data/operator/manual-2026-04-14.csv --output_dir=storage/app/market-data-manual-single-day-readable
```

## Important
This file is parser-valid for the current codebase. Final `READABLE` status still depends on local ticker master, coverage gate, and other runtime prerequisites.

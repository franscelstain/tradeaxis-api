# Anomaly Report
- Requested date: 2026-05-18
- Effective date: null
- Status: FAILED
- Dominant anomaly: PROMOTE_STARTED
- Consumer effect: fallback or no readable state
- Publication safety: requested date not proven readable as current sealed publication

# Anomaly Report
- Requested date: 2026-02-18
- Effective date: 2026-02-18
- Status: SUCCESS
- Dominant anomaly: ELIG_INSUFFICIENT_HISTORY
- Consumer effect: requested date readable
- Publication safety: current sealed publication present
